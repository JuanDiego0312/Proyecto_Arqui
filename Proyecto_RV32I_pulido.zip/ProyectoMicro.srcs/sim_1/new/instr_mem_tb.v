`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : instr_mem_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : instr_mem (WORDS = 256, HEX_FILE = "programa.hex")
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar que la memoria carga el archivo .hex real con $readmemh y que
 *    la lectura por dirección en bytes funciona (incluida una dirección no
 *    alineada y direcciones fuera de rango).
 *
 *  REQUISITO
 *    El archivo programa.hex (34 palabras del programa del profesor) debe estar
 *    en el directorio de simulación (en Vivado: agregarlo como archivo de simulación).
 *
 *  ESTÍMULOS
 *    addr = 0x00, 0x04, 0x08, 0x84 (última instrucción), 0x88 (primera palabra
 *    vacía), 0x01 (no alineada) y 0x400 (fuera de rango).
 *
 *  RESULTADOS ESPERADOS
 *    0x00 -> FE010113 | 0x04 -> 00812E23 | 0x08 -> 02010413 | 0x84 -> 00008067 |
 *    0x88 -> 0 | 0x01 -> FE010113 (se ignoran los 2 bits bajos) | 0x400 -> 0.
 * ============================================================================
 */
module instr_mem_tb;

    reg  [31:0] addr;
    wire [31:0] instr;
    integer     errors;

    instr_mem #(.WORDS(256), .HEX_FILE("programa.hex")) dut (.addr(addr), .instr(instr));

    task check;
        input [8*40-1:0] name;
        input [31:0] a;
        input [31:0] expected;
        begin
            addr = a; #10;
            if (instr === expected) $display("[PASS] %0s addr=0x%03X -> 0x%08X", name, a, instr);
            else begin
                $display("[FAIL] %0s addr=0x%03X -> 0x%08X (esperado 0x%08X)", name, a, instr, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE INSTR_MEM ===");
        #1;
        check("palabra 0 (addi sp,sp,-32)",  32'h000, 32'hFE010113);
        check("palabra 1 (sw s0,28(sp))",    32'h004, 32'h00812E23);
        check("palabra 2 (addi s0,sp,32)",   32'h008, 32'h02010413);
        check("ultima (jalr, ret)",          32'h084, 32'h00008067);
        check("primera palabra vacia",       32'h088, 32'h00000000);
        check("no alineada ignora bits bajos", 32'h001, 32'hFE010113);
        check("fuera de rango",              32'h400, 32'h00000000);
        if (errors == 0) $display("=== RESULTADO INSTR_MEM: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO INSTR_MEM: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
