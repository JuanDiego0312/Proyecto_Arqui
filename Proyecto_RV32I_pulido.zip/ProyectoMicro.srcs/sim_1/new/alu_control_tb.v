`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : alu_control_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : alu_control
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar que (alu_op, funct3) produce el código correcto para la ALU:
 *    0010 ADD, 0110 SUB, 0000 AND, 0011 SLL.
 *
 *  ESTÍMULOS
 *    alu_op = 00 (suma) y 01 (resta) con funct3 cualquiera (000 y 111);
 *    alu_op = 11 con funct3 = 000 (addi), 111 (andi), 001 (slli) y 101 (inválido);
 *    alu_op = 10 (tipo R reservado).
 *
 *  RESULTADOS ESPERADOS
 *    00 -> 0010 | 01 -> 0110 | 11/000 -> 0010 | 11/111 -> 0000 | 11/001 -> 0011 |
 *    11/otro -> 0010 | 10 -> 0010. Nunca se usa el bit 30 de la instrucción.
 * ============================================================================
 */
module alu_control_tb;

    reg  [1:0] alu_op;
    reg  [2:0] funct3;
    wire [3:0] alu_ctrl;
    integer    errors;

    alu_control dut (.alu_op(alu_op), .funct3(funct3), .alu_ctrl(alu_ctrl));

    task check;
        input [8*40-1:0] name;
        input [1:0] op;
        input [2:0] f3;
        input [3:0] expected;
        begin
            alu_op = op; funct3 = f3; #10;
            if (alu_ctrl === expected) $display("[PASS] %0s -> %b", name, alu_ctrl);
            else begin
                $display("[FAIL] %0s -> %b (esperado %b)", name, alu_ctrl, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE ALU_CONTROL ===");
        check("alu_op=00 funct3=000 (suma)",   2'b00, 3'b000, 4'b0010);
        check("alu_op=00 funct3=111 (suma)",   2'b00, 3'b111, 4'b0010);
        check("alu_op=01 funct3=000 (resta)",  2'b01, 3'b000, 4'b0110);
        check("alu_op=01 funct3=111 (resta)",  2'b01, 3'b111, 4'b0110);
        check("alu_op=11 funct3=000 (addi)",   2'b11, 3'b000, 4'b0010);
        check("alu_op=11 funct3=111 (andi)",   2'b11, 3'b111, 4'b0000);
        check("alu_op=11 funct3=001 (slli)",   2'b11, 3'b001, 4'b0011);
        check("alu_op=11 funct3=101 (otro)",   2'b11, 3'b101, 4'b0010);
        check("alu_op=10 (tipo R reservado)",  2'b10, 3'b000, 4'b0010);
        if (errors == 0) $display("=== RESULTADO ALU_CONTROL: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO ALU_CONTROL: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
