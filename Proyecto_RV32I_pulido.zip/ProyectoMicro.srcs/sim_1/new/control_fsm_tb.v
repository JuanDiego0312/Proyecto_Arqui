`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : control_fsm_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : control_fsm
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar, para cada familia de instrucciones, la secuencia de estados y
 *    las 11 salidas tipo Moore en cada ciclo, y que al terminar vuelva a S0.
 *
 *  ESTÍMULOS
 *    Para cada caso se aplica reset (1 flanco) y se mantiene el opcode fijo;
 *    se avanza de un flanco en uno y se compara en el flanco de bajada.
 *      addi 0010011 : S0 S1 S6 S7        lw  0000011 : S0 S1 S2 S3 S4
 *      sw   0100011 : S0 S1 S2 S5        bne 1100011 : S0 S1 S8
 *      jal  1101111 : S0 S1 S10 S7       jalr 1100111: S0 S1 S9 S10 S7
 *      lui  0110111 : S0 S1 S11          opcode inválido : S0 S1 S0
 *
 *  RESULTADOS ESPERADOS
 *    En cada estado las salidas coinciden con la tabla de control del diseño;
 *    tras el último estado de cada instrucción la FSM regresa a S0.
 * ============================================================================
 */
module control_fsm_tb;

    reg clk, reset;
    reg [6:0] opcode;
    wire pc_write, branch, pc_src, ir_write, reg_write, mem_read, mem_write;
    wire [1:0] alu_src_a, alu_src_b, alu_op, result_src;
    integer errors;

    control_fsm dut (.clk(clk), .reset(reset), .opcode(opcode),
        .pc_write(pc_write), .branch(branch), .pc_src(pc_src), .ir_write(ir_write),
        .reg_write(reg_write), .mem_read(mem_read), .mem_write(mem_write),
        .alu_src_a(alu_src_a), .alu_src_b(alu_src_b), .alu_op(alu_op), .result_src(result_src));

    always #5 clk = ~clk;

    // Compara las 11 salidas con lo esperado para un estado
    task chk;
        input [8*10-1:0] st;
        input pcw, br, pcs, irw, rw, mr, mw;
        input [1:0] asa, asb, aop, rs;
        begin
            if (pc_write===pcw && branch===br && pc_src===pcs && ir_write===irw &&
                reg_write===rw && mem_read===mr && mem_write===mw &&
                alu_src_a===asa && alu_src_b===asb && alu_op===aop && result_src===rs)
                $display("[PASS] %0s", st);
            else begin
                $display("[FAIL] %0s: pcw=%b br=%b pcs=%b irw=%b rw=%b mr=%b mw=%b asa=%b asb=%b aop=%b rs=%b",
                         st, pc_write, branch, pc_src, ir_write, reg_write, mem_read, mem_write,
                         alu_src_a, alu_src_b, alu_op, result_src);
                errors = errors + 1;
            end
        end
    endtask

    // Reset de un flanco y opcode fijo: deja la FSM en S0
    task start;
        input [6:0] op;
        begin
            opcode = op; reset = 1;
            @(posedge clk); @(negedge clk);
            reset = 0; #1;
        end
    endtask

    // Avanza un estado (un flanco de subida) y espera al flanco de bajada
    task step;
        begin
            @(posedge clk); @(negedge clk); #1;
        end
    endtask

    // Comprobaciones por estado (valores de la tabla de control)
    task s0;  begin chk("S0 FETCH",   1,0,0,1,0,0,0, 2'b00,2'b10,2'b00,2'b00); end endtask
    task s1;  begin chk("S1 DECODE",  0,0,0,0,0,0,0, 2'b01,2'b01,2'b00,2'b00); end endtask
    task s2;  begin chk("S2 MEM_ADR", 0,0,0,0,0,0,0, 2'b10,2'b01,2'b00,2'b00); end endtask
    task s3;  begin chk("S3 MEM_RD",  0,0,0,0,0,1,0, 2'b00,2'b00,2'b00,2'b00); end endtask
    task s4;  begin chk("S4 MEM_WB",  0,0,0,0,1,0,0, 2'b00,2'b00,2'b00,2'b01); end endtask
    task s5;  begin chk("S5 MEM_WR",  0,0,0,0,0,0,1, 2'b00,2'b00,2'b00,2'b00); end endtask
    task s6;  begin chk("S6 EXEC_I",  0,0,0,0,0,0,0, 2'b10,2'b01,2'b11,2'b00); end endtask
    task s7;  begin chk("S7 ALU_WB",  0,0,0,0,1,0,0, 2'b00,2'b00,2'b00,2'b00); end endtask
    task s8;  begin chk("S8 BRANCH",  0,1,1,0,0,0,0, 2'b10,2'b00,2'b01,2'b00); end endtask
    task s9;  begin chk("S9 EXEC_JR", 0,0,0,0,0,0,0, 2'b10,2'b01,2'b00,2'b00); end endtask
    task s10; begin chk("S10 JMP_LK", 1,0,1,0,0,0,0, 2'b01,2'b10,2'b00,2'b00); end endtask
    task s11; begin chk("S11 LUI_WB", 0,0,0,0,1,0,0, 2'b00,2'b00,2'b00,2'b10); end endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE CONTROL_FSM ===");
        clk = 0; reset = 1; opcode = 7'b0;

        $display("--- addi (S0 S1 S6 S7 S0) ---");
        start(7'b0010011); s0; step; s1; step; s6; step; s7; step; s0;

        $display("--- lw (S0 S1 S2 S3 S4 S0) ---");
        start(7'b0000011); s0; step; s1; step; s2; step; s3; step; s4; step; s0;

        $display("--- sw/sb (S0 S1 S2 S5 S0) ---");
        start(7'b0100011); s0; step; s1; step; s2; step; s5; step; s0;

        $display("--- bne/bge (S0 S1 S8 S0) ---");
        start(7'b1100011); s0; step; s1; step; s8; step; s0;

        $display("--- jal (S0 S1 S10 S7 S0) ---");
        start(7'b1101111); s0; step; s1; step; s10; step; s7; step; s0;

        $display("--- jalr (S0 S1 S9 S10 S7 S0) ---");
        start(7'b1100111); s0; step; s1; step; s9; step; s10; step; s7; step; s0;

        $display("--- lui (S0 S1 S11 S0) ---");
        start(7'b0110111); s0; step; s1; step; s11; step; s0;

        $display("--- opcode invalido (S0 S1 S0) ---");
        start(7'b0000000); s0; step; s1; step; s0;

        if (errors == 0) $display("=== RESULTADO CONTROL_FSM: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO CONTROL_FSM: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
