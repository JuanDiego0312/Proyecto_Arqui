`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : branch_logic_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : branch_logic
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar pc_en = pc_write | (branch & cond) para todas las condiciones
 *    de salto (beq, bne, blt, bge), un funct3 no soportado y los casos con
 *    branch = 0 y pc_write = 1.
 *
 *  ESTÍMULOS
 *    Con pc_write = 0 y branch = 1: barrido de funct3 en {000, 001, 100, 101, 111}
 *    y de las cuatro combinaciones de (zero, lt).
 *    Luego branch = 0 (con condición verdadera) y pc_write = 1 (con condición falsa).
 *
 *  RESULTADOS ESPERADOS
 *    000 -> pc_en = zero | 001 -> ~zero | 100 -> lt | 101 -> ~lt | 111 -> 0.
 *    branch = 0 -> pc_en = 0 ; pc_write = 1 -> pc_en = 1 siempre.
 * ============================================================================
 */
module branch_logic_tb;

    reg pc_write, branch, zero, lt;
    reg [2:0] funct3;
    wire pc_en;
    integer errors, k, z, l;
    reg [2:0] f3;
    reg expected;

    branch_logic dut (.pc_write(pc_write), .branch(branch), .funct3(funct3),
                      .zero(zero), .lt(lt), .pc_en(pc_en));

    task check;
        input [8*40-1:0] name;
        input exp;
        begin
            #5;
            if (pc_en === exp) $display("[PASS] %0s pc_en=%b", name, pc_en);
            else begin
                $display("[FAIL] %0s pc_en=%b (esperado %b)", name, pc_en, exp);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE BRANCH_LOGIC ===");

        // Barrido de condiciones con branch = 1 y pc_write = 0
        pc_write = 0; branch = 1;
        for (k = 0; k < 5; k = k + 1) begin
            case (k)
                0: f3 = 3'b000;  // beq
                1: f3 = 3'b001;  // bne
                2: f3 = 3'b100;  // blt
                3: f3 = 3'b101;  // bge
                default: f3 = 3'b111;  // no soportado
            endcase
            for (z = 0; z < 2; z = z + 1)
                for (l = 0; l < 2; l = l + 1) begin
                    funct3 = f3; zero = z; lt = l;
                    case (f3)
                        3'b000: expected = zero;
                        3'b001: expected = ~zero;
                        3'b100: expected = lt;
                        3'b101: expected = ~lt;
                        default: expected = 1'b0;
                    endcase
                    check("branch=1 barrido funct3/zero/lt", expected);
                end
        end

        // branch = 0: aunque la condición sea verdadera no salta
        pc_write = 0; branch = 0; funct3 = 3'b001; zero = 0; lt = 0;
        check("branch=0 (bne cumplido) no salta", 1'b0);

        // pc_write = 1: carga incondicional aunque la condición sea falsa
        pc_write = 1; branch = 1; funct3 = 3'b001; zero = 1; lt = 1;
        check("pc_write=1 fuerza pc_en", 1'b1);
        pc_write = 1; branch = 0; funct3 = 3'b111;
        check("pc_write=1 con branch=0", 1'b1);

        if (errors == 0) $display("=== RESULTADO BRANCH_LOGIC: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO BRANCH_LOGIC: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
