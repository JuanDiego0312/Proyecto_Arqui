`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : cpu_top_link_tb   (prueba COMPLEMENTARIA del procesador completo)
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : cpu_top, con otro programa en la memoria de instrucciones
 *
 *  OBJETIVO DE LA PRUEBA
 *    Cubrir lo que el programa del profesor NO ejercita: escritura del enlace
 *    en jal/jalr con rd != x0 (OldPC + 4), jalr con rd == rs1, bge/blt con un
 *    operando negativo (comparación con signo) y una instrucción no soportada.
 *
 *  REQUISITO
 *    programa_link.hex en el directorio de simulación. Solo cambia el archivo
 *    de la memoria de instrucciones (defparam); la arquitectura no se toca.
 *
 *  ESTÍMULOS (programa_link.hex)
 *    00 addi x10,x0,5        04 jal  x1,0x10        08 addi x12,x0,7
 *    0C jal  x0,0  (fin)     10 addi x11,x10,-8     14 bge  x11,x0,+8 (no salta)
 *    18 addi x13,x0,1        1C blt  x11,x0,+8 (salta) 20 addi x14,x0,1 (se salta)
 *    24 add  x15,x10,x10 (tipo R, NO soportada: debe comportarse como NOP)
 *    28 sw   x11,0xE0(x0)    2C jalr x1,0(x1)  (vuelve a 0x08; x1 = 0x30)
 *    Reloj de 10 ns, reset por 2 flancos; se corren 80 ciclos.
 *
 *  RESULTADOS ESPERADOS
 *    x1 = 0x30, x10 = 5, x11 = 0xFFFFFFFD, x12 = 7, x13 = 1, x14 = 0, x15 = 0,
 *    memoria[0xE0] = 0xFFFFFFFD y PC detenido en 0x0C.
 * ============================================================================
 */
module cpu_top_link_tb;

    reg clk, reset;
    integer errors;

    cpu_top dut (.clk(clk), .reset(reset));
    defparam dut.u_imem.HEX_FILE = "programa_link.hex";

    always #5 clk = ~clk;

    task check;
        input [8*40-1:0] name;
        input [31:0] got;
        input [31:0] expected;
        begin
            if (got === expected) $display("[PASS] %0s = 0x%08X", name, got);
            else begin
                $display("[FAIL] %0s = 0x%08X (esperado 0x%08X)", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0; clk = 0; reset = 1;
        $display("=== INICIO DE PRUEBAS DE CPU_TOP (ENLACE Y SIGNO) ===");
        repeat (2) @(posedge clk);
        @(negedge clk) reset = 0;
        repeat (80) @(negedge clk);

        check("x1 (enlace de jalr x1,0(x1))", dut.u_rf.regs[1],  32'h00000030);
        check("x10",                          dut.u_rf.regs[10], 32'h00000005);
        check("x11 = -3",                     dut.u_rf.regs[11], 32'hFFFFFFFD);
        check("x12 (tras volver de jal)",     dut.u_rf.regs[12], 32'h00000007);
        check("x13 (bge -3>=0 no salta)",     dut.u_rf.regs[13], 32'h00000001);
        check("x14 (blt -3<0 salta)",         dut.u_rf.regs[14], 32'h00000000);
        check("x15 (add no soportada = NOP)", dut.u_rf.regs[15], 32'h00000000);
        check("mem[0xE0] (sw x11)", {dut.u_dmem.mem[8'hE3], dut.u_dmem.mem[8'hE2],
                                     dut.u_dmem.mem[8'hE1], dut.u_dmem.mem[8'hE0]}, 32'hFFFFFFFD);
        check("PC detenido en 'j .'",         dut.pc,            32'h0000000C);

        if (errors == 0) $display("=== RESULTADO CPU_TOP_LINK: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO CPU_TOP_LINK: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
