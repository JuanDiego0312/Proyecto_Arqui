`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : mux3_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : mux3 (WIDTH = 32)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar las tres selecciones válidas y el valor de la selección 11.
 *  ESTÍMULOS
 *    d0 = 0x11111111, d1 = 0x22222222, d2 = 0x33333333; sel = 00, 01, 10 y 11.
 *  RESULTADOS ESPERADOS
 *    y = d0, d1, d2 y 0 respectivamente.
 * ============================================================================
 */
module mux3_tb;

    reg [1:0] sel;
    reg [31:0] d0, d1, d2;
    wire [31:0] y;
    integer errors;

    mux3 #(.WIDTH(32)) dut (.sel(sel), .d0(d0), .d1(d1), .d2(d2), .y(y));

    task check;
        input [8*40-1:0] name;
        input [1:0] s;
        input [31:0] expected;
        begin
            sel = s; #10;
            if (y === expected) $display("[PASS] %0s -> 0x%08X", name, y);
            else begin
                $display("[FAIL] %0s -> 0x%08X (esperado 0x%08X)", name, y, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE MUX3 ===");
        d0 = 32'h11111111; d1 = 32'h22222222; d2 = 32'h33333333;
        check("sel=00 -> d0", 2'b00, 32'h11111111);
        check("sel=01 -> d1", 2'b01, 32'h22222222);
        check("sel=10 -> d2", 2'b10, 32'h33333333);
        check("sel=11 -> 0",  2'b11, 32'h00000000);
        if (errors == 0) $display("=== RESULTADO MUX3: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO MUX3: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
