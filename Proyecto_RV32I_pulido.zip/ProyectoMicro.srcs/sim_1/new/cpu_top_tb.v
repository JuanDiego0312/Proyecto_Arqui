`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : cpu_top_tb
 *  Proyecto  : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Módulo bajo prueba : cpu_top (procesador completo)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Ejecutar el programa completo del profesor (programa.hex), generar el
 *    volcado de la memoria de datos (memory_dump.txt) y comprobar
 *    automáticamente que el resultado es el esperado.
 *
 *  REQUISITO
 *    programa.hex debe estar agregado al proyecto como fuente de simulación.
 *    En Vivado la simulación debe correr al menos 2 us ("Run All").
 *
 *  ESTÍMULOS
 *    1. Reloj de 10 ns de período.
 *    2. reset = 1 durante dos flancos de subida; se libera en un flanco de
 *       bajada para no coincidir con el flanco activo del reloj.
 *    3. El procesador corre solo. En cada flanco de bajada se cuenta un ciclo
 *       completado y se revisa si el programa terminó. Se considera terminado cuando:
 *         a) el PC vuelve a 0 después de haber salido de 0: es el "ret" final
 *            de main (jalr con ra = 0). No hay sistema operativo, así que el
 *            programa volvería a empezar; por eso el volcado se hace aquí,
 *            al terminar la primera pasada; o
 *         b) se ejecuta "j ." (0x0000006F), un salto a sí mismo; o
 *         c) se llega a MAX_CYCLES ciclos (se hace el volcado y se avisa).
 *    4. Se espera un ciclo más (para que termine la última instrucción), se
 *       llama a dut.u_dmem.dump_memory y se comparan memoria y registros.
 *
 *  RESULTADOS ESPERADOS (programa del profesor: 45 instrucciones, 185 ciclos)
 *    Memoria de datos:
 *      0xE0 = 0x62000000   a = 'b' (el char está en el byte 0xE3)
 *      0xE4 = 0x0000C7DF   r = 0xC7DF
 *      0xE8 = 0x00000002   i = 2 (valor con el que sale del for)
 *      0xEC = 0x00000002   b = (33 << 1) & 0xF
 *      0xFC = 0x00000000   s0 guardado al entrar a main
 *    Registros: x2 (sp) = 0x100 y x8 (s0) = 0 (restaurados al salir de main).
 *    Se imprime [PASS]/[FAIL] por cada valor y un resumen final.
 *
 *  PARA PROBAR OTRO PROGRAMA
 *    Se cambia solo el archivo .hex. Las comparaciones de arriba son las del
 *    programa del profesor: con otro programa se ponen en 0 con el parámetro
 *    CHECK_PROFESSOR_PROGRAM y se revisa directamente el volcado.
 * ============================================================================
 */
module cpu_top_tb;

    parameter MAX_CYCLES              = 5000;   // límite de seguridad
    parameter CHECK_PROFESSOR_PROGRAM = 1;      // 1 = comparar con los valores esperados

    reg clk;
    reg reset;

    integer cycle_count;     // ciclos de reloj desde que se liberó el reset
    integer errors;          // comparaciones fallidas
    reg     left_zero;       // 1 cuando el PC ya salió de la dirección 0
    reg     finished;        // 1 cuando el programa terminó
    reg     timed_out;       // 1 si se llegó a MAX_CYCLES sin terminar

    cpu_top dut (.clk(clk), .reset(reset));

    // Reloj de 10 ns
    always #5 clk = ~clk;

    // Compara una palabra de la memoria de datos con el valor esperado
    task check_mem;
        input [31:0] addr;
        input [31:0] expected;
        input [8*30-1:0] description;
        reg [31:0] actual;
        begin
            actual = {dut.u_dmem.mem[addr + 3], dut.u_dmem.mem[addr + 2],
                      dut.u_dmem.mem[addr + 1], dut.u_dmem.mem[addr]};
            if (actual === expected)
                $display(" [PASS] Memoria [0x%0X] = 0x%08X (%0s)", addr, actual, description);
            else begin
                $display(" [FAIL] Memoria [0x%0X] = 0x%08X | ESPERADO: 0x%08X (%0s)",
                         addr, actual, expected, description);
                errors = errors + 1;
            end
        end
    endtask

    // Compara un registro del banco con el valor esperado
    task check_reg;
        input [4:0]  index;
        input [31:0] expected;
        input [8*20-1:0] description;
        reg [31:0] actual;
        begin
            actual = dut.u_rf.regs[index];
            if (actual === expected)
                $display(" [PASS] Registro %0s = 0x%08X", description, actual);
            else begin
                $display(" [FAIL] Registro %0s = 0x%08X | ESPERADO: 0x%08X",
                         description, actual, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("");
        $display("========================================================");
        $display("   INICIO DE SIMULACION: MT-7003 RV32I MULTICICLO");
        $display("========================================================");

        clk = 0; reset = 1;
        cycle_count = 0; errors = 0;
        left_zero = 0; finished = 0; timed_out = 0;

        // Reset: dos flancos de subida y se libera en el flanco de bajada
        repeat (2) @(posedge clk);
        @(negedge clk) reset = 0;

        // Ejecución: un ciclo por vuelta, hasta que el programa termine
        while (!finished) begin
            @(negedge clk);
            cycle_count = cycle_count + 1;

            if (dut.pc != 32'd0)
                left_zero = 1;

            if (left_zero && dut.pc == 32'd0)            // a) ret volvió a 0
                finished = 1;
            else if (dut.ir == 32'h0000006F)             // b) "j ."
                finished = 1;
            else if (cycle_count >= MAX_CYCLES) begin    // c) límite de seguridad
                finished = 1; timed_out = 1;
            end
        end

        // Un ciclo más: es el que completa la última instrucción
        @(negedge clk);
        cycle_count = cycle_count + 1;

        if (timed_out) begin
            $display("[ERROR] El programa no termino en %0d ciclos. PC = 0x%08X", MAX_CYCLES, dut.pc);
            $display("        Revise que programa.hex este agregado como fuente de simulacion.");
            errors = errors + 1;
        end else
            $display("[INFO] Programa terminado en %0d ciclos de reloj.", cycle_count);

        // Volcado de la memoria de datos (requisito del enunciado)
        dut.u_dmem.dump_memory("memory_dump.txt");

        if (CHECK_PROFESSOR_PROGRAM) begin
            $display("--------------------------------------------------------");
            $display("   RESULTADOS ESPERADOS DEL PROGRAMA DEL PROFESOR");
            $display("--------------------------------------------------------");
            check_mem(32'hE0, 32'h62000000, "a = 'b' (byte en 0xE3)");
            check_mem(32'hE4, 32'h0000C7DF, "r = 0xC7DF");
            check_mem(32'hE8, 32'h00000002, "i = 2");
            check_mem(32'hEC, 32'h00000002, "b = (33<<1)&0xF");
            check_mem(32'hFC, 32'h00000000, "s0 guardado");
            check_reg(5'd2, 32'h00000100, "sp (x2)");
            check_reg(5'd8, 32'h00000000, "s0 (x8)");
            check_mem(32'h00, 32'h00000000, "memoria sin usar");
            if (cycle_count == 185) $display(" [PASS] Ciclos = 185");
            else begin
                $display(" [FAIL] Ciclos = %0d | ESPERADO: 185", cycle_count);
                errors = errors + 1;
            end
        end

        $display("--------------------------------------------------------");
        if (errors == 0) $display(" [EXITO] SIMULACION FINALIZADA SIN ERRORES.");
        else             $display(" [ALERTA] SIMULACION FINALIZADA CON %0d ERRORES.", errors);
        $display("========================================================");
        $finish;
    end

endmodule
