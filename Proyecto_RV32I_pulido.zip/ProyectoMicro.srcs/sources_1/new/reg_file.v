`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : reg_file
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 ("Banco de registros")
 *
 *  FUNCIÓN
 *    Banco de 32 registros de 32 bits (x0..x31) con dos puertos de lectura
 *    combinacional y un puerto de escritura síncrona.
 *
 *  RAZÓN DE EXISTENCIA
 *    Guarda los registros de la arquitectura RISC-V. Toda instrucción lo usa:
 *    lee rs1 y rs2 en el estado S1 (addi, lw, sw, bne, jalr...) y escribe rd
 *    en el Write-back (addi, lw, lui, jal...).
 *
 *  ENTRADAS
 *    clk          : reloj (se escribe en el flanco de subida)
 *    reset        : reset síncrono activo en alto
 *    we           : habilitación de escritura (RegWrite de la UC)
 *    ra1   [4:0]  : registro a leer por el puerto 1 (rs1 = IR[19:15])
 *    ra2   [4:0]  : registro a leer por el puerto 2 (rs2 = IR[24:20])
 *    wa    [4:0]  : registro a escribir (rd = IR[11:7])
 *    wd    [31:0] : dato a escribir
 *  SALIDAS
 *    rd1   [31:0] : contenido del registro ra1
 *    rd2   [31:0] : contenido del registro ra2
 *  PARÁMETROS
 *    SP_INIT (0x100) : valor de x2 (sp, puntero de pila) después del reset
 *
 *  NOTAS
 *    - x0 vale siempre 0: se bloquea su escritura y además su lectura entrega
 *      0 (doble protección). Ej.: "sw zero,-24(s0)" guarda un 0.
 *    - Con reset todos los registros quedan en 0, excepto x2 = SP_INIT, porque
 *      el programa compilado usa la pila desde 0x100 hacia abajo (0xE0..0xFC).
 * ============================================================================
 */
module reg_file #(
    parameter SP_INIT = 32'h00000100
)(
    input  clk,
    input  reset,
    input  we,
    input  [4:0]  ra1,
    input  [4:0]  ra2,
    input  [4:0]  wa,
    input  [31:0] wd,
    output [31:0] rd1,
    output [31:0] rd2
);

    reg [31:0] regs [0:31];
    integer i;

    // Lectura combinacional (x0 siempre entrega 0)
    assign rd1 = (ra1 == 5'd0) ? 32'b0 : regs[ra1];
    assign rd2 = (ra2 == 5'd0) ? 32'b0 : regs[ra2];

    // Escritura síncrona
    always @(posedge clk) begin
        if (reset) begin
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'b0;
            regs[2] <= SP_INIT;              // sp: la última asignación es la que queda
        end else if (we && (wa != 5'd0)) begin
            regs[wa] <= wd;                  // x0 nunca se escribe
        end
    end

endmodule
