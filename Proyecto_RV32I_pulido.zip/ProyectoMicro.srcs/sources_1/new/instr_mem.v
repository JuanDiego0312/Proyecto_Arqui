`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : instr_mem
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 ("Memoria de instrucciones")
 *
 *  FUNCIÓN
 *    Memoria de instrucciones de solo lectura, con lectura combinacional.
 *    Su contenido se carga desde un archivo de texto hexadecimal al iniciar
 *    la simulación.
 *
 *  RAZÓN DE EXISTENCIA
 *    Guarda el programa compilado. Es el ÚNICO componente que se cambia
 *    durante la evaluación: para probar otro programa basta con cambiar el
 *    archivo .hex; el resto del procesador no se toca.
 *
 *  ENTRADAS
 *    addr  [31:0] : dirección en BYTES (el PC). Los 2 bits bajos se ignoran
 *                   porque cada instrucción ocupa 4 bytes.
 *  SALIDAS
 *    instr [31:0] : instrucción guardada en esa dirección; 0 si la dirección
 *                   queda fuera de la memoria
 *  PARÁMETROS
 *    WORDS    (256)            : cantidad de instrucciones que caben (1 KiB)
 *    HEX_FILE ("programa.hex") : archivo con el programa
 *
 *  FORMATO DEL ARCHIVO .hex
 *    Una instrucción por línea, 8 dígitos hexadecimales, sin prefijo "0x".
 *    La línea 1 es la dirección 0, la línea 2 la dirección 4, etc.
 *
 *  NOTAS
 *    - Las posiciones que el archivo no llena quedan en 0.
 *    - El aviso "Not enough words in the file" de $readmemh es normal: el
 *      programa tiene menos de WORDS instrucciones.
 *    - En Vivado el archivo .hex debe agregarse al proyecto como fuente de
 *      simulación (ver LEEME.txt); así Vivado lo copia a la carpeta donde
 *      corre el simulador.
 * ============================================================================
 */
module instr_mem #(
    parameter WORDS    = 256,
    parameter HEX_FILE = "programa.hex"
)(
    input  [31:0] addr,
    output [31:0] instr
);

    reg [31:0] mem [0:WORDS-1];
    integer i;

    // Contenido inicial: todo en 0 y luego el programa
    initial begin
        for (i = 0; i < WORDS; i = i + 1)
            mem[i] = 32'b0;
        $readmemh(HEX_FILE, mem);
    end

    // Número de palabra = dirección en bytes / 4
    wire [31:0] word_addr = addr >> 2;

    assign instr = (word_addr < WORDS) ? mem[word_addr] : 32'b0;

endmodule
