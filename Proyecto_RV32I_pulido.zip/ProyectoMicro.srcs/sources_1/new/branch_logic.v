`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : branch_logic
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, págs. 2 y 6 ("Lógica de salto")
 *
 *  FUNCIÓN
 *    Lógica combinacional que decide si el PC se carga en este ciclo:
 *        pc_en = pc_write | (branch & cond)
 *
 *  RAZÓN DE EXISTENCIA
 *    La FSM es tipo Moore: sus salidas no pueden depender de las banderas de
 *    la ALU. Por eso la FSM solo avisa "estoy en un salto condicional"
 *    (branch) y este bloque revisa si la condición del salto se cumple.
 *    bne salta si rs1 != rs2 (zero = 0); bge salta si rs1 >= rs2 con signo
 *    (lt = 0).
 *
 *  ENTRADAS
 *    pc_write      : carga incondicional del PC (estados S0 y S10)
 *    branch        : 1 en el estado S8 (salto condicional)
 *    funct3 [2:0]  : IR[14:12], tipo de salto
 *    zero          : bandera de la ALU: 1 si A - B = 0, es decir A == B
 *    lt            : bandera de la ALU: 1 si A < B con signo
 *  SALIDAS
 *    pc_en         : 1 = el PC se carga en el próximo flanco de reloj
 *
 *  CONDICIÓN SEGÚN funct3
 *    000 beq : zero        001 bne : ~zero       (bne lo usa el programa)
 *    100 blt : lt          101 bge : ~lt         (bge lo usa el programa)
 *    otro    : 0 (nunca salta)
 *    beq y blt no los necesita el programa, pero salen gratis con las mismas
 *    banderas.
 * ============================================================================
 */
module branch_logic (
    input  pc_write,
    input  branch,
    input  [2:0] funct3,
    input  zero,
    input  lt,
    output pc_en
);

    reg cond;    // 1 = la condición del salto se cumple

    always @(*) begin
        case (funct3)
            3'b000:  cond = zero;     // beq: iguales
            3'b001:  cond = ~zero;    // bne: distintos
            3'b100:  cond = lt;       // blt: menor (con signo)
            3'b101:  cond = ~lt;      // bge: mayor o igual (con signo)
            default: cond = 1'b0;     // salto no soportado
        endcase
    end

    assign pc_en = pc_write | (branch & cond);

endmodule
