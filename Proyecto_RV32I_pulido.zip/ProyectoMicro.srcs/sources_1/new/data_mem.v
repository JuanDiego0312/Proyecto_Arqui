`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : data_mem
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 ("Memoria de datos")
 *
 *  FUNCIÓN
 *    Memoria de datos (RAM) organizada por BYTES, en formato little-endian
 *    (el byte menos significativo queda en la dirección más baja).
 *    Lectura combinacional de una palabra y escritura síncrona de una
 *    palabra (sw) o de un byte (sb).
 *
 *  RAZÓN DE EXISTENCIA
 *    Aquí viven las variables del programa en C (la pila). lw y sw acceden
 *    4 bytes; sb escribe 1 solo byte en una dirección que puede no ser
 *    múltiplo de 4 (sb a5,-29(s0) escribe en 0xE3), por eso la memoria se
 *    guarda byte por byte. También contiene el task dump_memory, que genera
 *    el volcado de memoria que exige el enunciado.
 *
 *  ENTRADAS
 *    clk             : reloj (se escribe en el flanco de subida)
 *    mem_read        : 1 = rdata entrega la palabra leída; 0 = rdata vale 0
 *    mem_write       : 1 = se escribe en el flanco de subida
 *    funct3  [2:0]   : tamaño de la escritura (IR[14:12]):
 *                        000 = sb (1 byte)    010 = sw (4 bytes)
 *                        otro valor = no se escribe nada
 *    addr    [31:0]  : dirección en bytes (solo se usan los ADDR_BITS bajos)
 *    wdata   [31:0]  : dato a escribir (sb usa solo wdata[7:0])
 *  SALIDAS
 *    rdata   [31:0]  : palabra de 4 bytes que contiene la dirección pedida
 *  PARÁMETROS
 *    ADDR_BITS (8)   : la memoria tiene 2^ADDR_BITS bytes (256 por defecto)
 *
 *  TASK dump_memory(filename)
 *    Escribe en un archivo de texto toda la memoria, una palabra por línea:
 *        Direccion de Memoria    Valor en hexadecimal
 *        0x0    0x00000000
 *        0x4    0x00000000
 *        ...
 *    Se llama desde un testbench:  dut.u_dmem.dump_memory("memory_dump.txt");
 *    El nombre del archivo puede tener hasta 40 caracteres.
 *
 *  NOTAS
 *    - Palabras: se accede a la palabra alineada (se ignoran los 2 bits bajos).
 *    - Direcciones mayores a 2^ADDR_BITS - 1: solo cuentan los bits bajos.
 * ============================================================================
 */
module data_mem #(
    parameter ADDR_BITS = 8
)(
    input  clk,
    input  mem_read,
    input  mem_write,
    input  [2:0]  funct3,
    input  [31:0] addr,
    input  [31:0] wdata,
    output [31:0] rdata
);

    localparam BYTES = (1 << ADDR_BITS);     // tamaño de la memoria en bytes

    // Tamaños de escritura (funct3)
    localparam [2:0] F3_BYTE = 3'b000,       // sb
                     F3_WORD = 3'b010;       // sw

    reg [7:0] mem [0:BYTES-1];
    integer i;

    // La memoria inicia en 0 para que el volcado no muestre valores indefinidos
    initial begin
        for (i = 0; i < BYTES; i = i + 1)
            mem[i] = 8'b0;
    end

    // byte_idx: byte exacto que se accede. word_idx: inicio de su palabra.
    wire [ADDR_BITS-1:0] byte_idx = addr[ADDR_BITS-1:0];
    wire [ADDR_BITS-1:0] word_idx = {byte_idx[ADDR_BITS-1:2], 2'b00};

    // Lectura combinacional de la palabra (little-endian)
    assign rdata = mem_read ? {mem[word_idx + 3], mem[word_idx + 2],
                               mem[word_idx + 1], mem[word_idx]}
                            : 32'b0;

    // Escritura síncrona
    always @(posedge clk) begin
        if (mem_write) begin
            case (funct3)
                F3_BYTE: mem[byte_idx] <= wdata[7:0];      // sb: solo ese byte
                F3_WORD: begin                             // sw: los 4 bytes
                    mem[word_idx]     <= wdata[7:0];
                    mem[word_idx + 1] <= wdata[15:8];
                    mem[word_idx + 2] <= wdata[23:16];
                    mem[word_idx + 3] <= wdata[31:24];
                end
                default: ;                                 // tamaño no soportado
            endcase
        end
    end

    // Volcado de la memoria a un archivo de texto (solo para simulación)
    task dump_memory;
        input [8*40-1:0] filename;
        integer fd;
        integer a;
        begin
            fd = $fopen(filename, "w");
            if (fd != 0) begin
                $fwrite(fd, "Direccion de Memoria    Valor en hexadecimal\n");
                for (a = 0; a < BYTES; a = a + 4)
                    $fwrite(fd, "0x%0X    0x%02X%02X%02X%02X\n",
                            a, mem[a + 3], mem[a + 2], mem[a + 1], mem[a]);
                $fclose(fd);
                $display("[INFO] Volcado de memoria completado en: %0s", filename);
            end else begin
                $display("[ERROR] No se pudo crear el archivo de volcado: %0s", filename);
            end
        end
    endtask

endmodule
