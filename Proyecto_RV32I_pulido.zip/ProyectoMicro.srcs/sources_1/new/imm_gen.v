`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : imm_gen   ("unidad de signo" de la rúbrica)
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, págs. 2 y 6
 *
 *  FUNCIÓN
 *    Generador de inmediatos combinacional: arma el inmediato de 32 bits a
 *    partir de la instrucción y le extiende el signo (copia el bit 31).
 *
 *  RAZÓN DE EXISTENCIA
 *    Cada formato de RISC-V guarda el inmediato en bits distintos de la
 *    instrucción. Este módulo mira el opcode, elige el formato y entrega el
 *    inmediato ya listo para la ALU (o para escribirlo en rd, en lui).
 *
 *  ENTRADAS
 *    instr [31:0] : instrucción completa (salida del registro IR)
 *  SALIDAS
 *    imm   [31:0] : inmediato extendido en signo; 0 si el opcode no se soporta
 *
 *  FORMATOS
 *    Fmt  opcode                       instrucciones            inmediato
 *     I   0010011, 0000011, 1100111    addi slli andi lw jalr   IR[31:20]
 *     S   0100011                      sw sb                    {IR[31:25], IR[11:7]}
 *     B   1100011                      bne bge                  {IR[31], IR[7], IR[30:25], IR[11:8], 0}
 *     U   0110111                      lui                      {IR[31:12], 12 ceros}
 *     J   1101111                      jal                      {IR[31], IR[19:12], IR[20], IR[30:21], 0}
 *
 *  NOTAS
 *    - En B y J el bit 0 siempre es 0: los saltos van a direcciones pares.
 *    - Ejemplo: sb a5,-29(s0) = 0xFEF401A3 -> formato S -> 0xFFFFFFE3 (-29).
 * ============================================================================
 */
module imm_gen (
    input  [31:0] instr,
    output reg [31:0] imm
);

    // Opcodes soportados (IR[6:0])
    localparam [6:0] OP_I_ARI  = 7'b0010011,   // addi, slli, andi
                     OP_LOAD   = 7'b0000011,   // lw
                     OP_JALR   = 7'b1100111,   // jalr
                     OP_STORE  = 7'b0100011,   // sw, sb
                     OP_BRANCH = 7'b1100011,   // bne, bge
                     OP_LUI    = 7'b0110111,   // lui
                     OP_JAL    = 7'b1101111;   // jal

    wire [6:0] opcode = instr[6:0];
    wire       sign   = instr[31];             // bit de signo de todos los formatos

    always @(*) begin
        case (opcode)
            OP_I_ARI, OP_LOAD, OP_JALR:        // formato I
                imm = {{20{sign}}, instr[31:20]};
            OP_STORE:                          // formato S
                imm = {{20{sign}}, instr[31:25], instr[11:7]};
            OP_BRANCH:                         // formato B
                imm = {{19{sign}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0};
            OP_LUI:                            // formato U
                imm = {instr[31:12], 12'b0};
            OP_JAL:                            // formato J
                imm = {{11{sign}}, instr[31], instr[19:12], instr[20], instr[30:21], 1'b0};
            default:                           // opcode no soportado
                imm = 32'b0;
        endcase
    end

endmodule
