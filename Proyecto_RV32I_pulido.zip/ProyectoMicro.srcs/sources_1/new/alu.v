`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : alu
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, págs. 2 y 6
 *
 *  FUNCIÓN
 *    Unidad aritmético-lógica combinacional de 32 bits. Hace una de cuatro
 *    operaciones (suma, resta, AND, desplazamiento a la izquierda) y entrega
 *    dos banderas para los saltos condicionales.
 *
 *  RAZÓN DE EXISTENCIA
 *    En el multiciclo hay UNA sola ALU y se reutiliza en estados distintos:
 *      S0  PC + 4                   (toda instrucción)
 *      S1  OldPC + inmediato        (destino de bne, bge y jal)
 *      S2  A + inmediato            (dirección de lw, sw y sb)
 *      S6  A op inmediato           (addi: +, andi: &, slli: <<)
 *      S8  A - B                    (comparación de bne y bge)
 *      S9  A + inmediato            (destino de jalr)
 *      S10 OldPC + 4                (dirección de retorno de jal y jalr)
 *
 *  ENTRADAS
 *    a        [31:0] : operando A (sale del mux ALUSrcA: PC, OldPC o registro A)
 *    b        [31:0] : operando B (sale del mux ALUSrcB: registro B, inmediato o 4)
 *    alu_ctrl [3:0]  : operación, generada por alu_control
 *                        0010 = ADD   0110 = SUB   0000 = AND   0011 = SLL
 *  SALIDAS
 *    result   [31:0] : resultado de la operación (0 si alu_ctrl no es válido)
 *    zero            : 1 si result == 0. Con SUB significa a == b (la usa bne)
 *    lt              : 1 si a < b interpretados CON SIGNO (la usa bge)
 *
 *  NOTAS
 *    - lt se calcula comparando a y b directamente y no con el signo de la
 *      resta, porque la resta puede desbordarse (ej.: 0x7FFFFFFF - (-1)).
 *    - SLL usa solo b[4:0]: en RV32I el desplazamiento va de 0 a 31.
 * ============================================================================
 */
module alu (
    input  [31:0] a,
    input  [31:0] b,
    input  [3:0]  alu_ctrl,
    output reg [31:0] result,
    output        zero,
    output        lt
);

    // Códigos de operación (los mismos que genera alu_control)
    localparam [3:0] ALU_AND = 4'b0000,
                     ALU_ADD = 4'b0010,
                     ALU_SLL = 4'b0011,
                     ALU_SUB = 4'b0110;

    // Operación seleccionada. El "default" cubre los códigos no usados y
    // evita que se infiera un latch.
    always @(*) begin
        case (alu_ctrl)
            ALU_ADD: result = a + b;
            ALU_SUB: result = a - b;
            ALU_AND: result = a & b;
            ALU_SLL: result = a << b[4:0];
            default: result = 32'b0;
        endcase
    end

    // Banderas para la lógica de salto
    assign zero = (result == 32'b0);
    assign lt   = ($signed(a) < $signed(b));

endmodule
