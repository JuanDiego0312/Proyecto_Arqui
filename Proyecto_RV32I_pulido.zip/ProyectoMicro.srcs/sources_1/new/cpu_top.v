`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : cpu_top   (MÓDULO PRINCIPAL)
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 (diagrama completo)
 *             y págs. 7 a 12 (ruta activa de cada tipo de instrucción)
 *
 *  FUNCIÓN
 *    Procesador RISC-V RV32I multiciclo completo: la RUTA DE DATOS (todo lo
 *    instanciado aquí excepto u_ctrl) más la UNIDAD DE CONTROL (u_ctrl).
 *    Instrucciones soportadas (11): addi, slli, andi, lw, jalr (formato I),
 *    sw, sb (S), bne, bge (B), lui (U) y jal (J).
 *
 *  RAZÓN DE EXISTENCIA
 *    Es el circuito final que pide el enunciado. Tiene ÚNICAMENTE dos
 *    entradas: clk y reset. Para ejecutar otro programa solo se cambia el
 *    archivo .hex de la memoria de instrucciones (u_imem).
 *
 *  ENTRADAS
 *    clk   : reloj del sistema
 *    reset : reset síncrono activo en alto. Deja PC = 0, la FSM en S0,
 *            x2 (sp) = 0x100 y el resto de registros en 0.
 *  SALIDAS
 *    ninguna (el resultado se observa en la memoria de datos, con el volcado)
 *
 *  BLOQUES (nombre de instancia = nombre en el diagrama)
 *    Registros : u_pc (PC), u_ir (IR), u_oldpc (OldPC), u_a (A), u_b (B),
 *                u_aluout (ALUOut), u_mdr (MDR)
 *    Memorias  : u_imem (memoria de instrucciones), u_dmem (memoria de datos)
 *    Datos     : u_rf (banco de registros), u_imm (ImmGen), u_alu (ALU)
 *    Muxes     : u_pcmux (PCSrc), u_srca (ALUSrcA), u_srcb (ALUSrcB),
 *                u_result (ResultSrc)
 *    Control   : u_ctrl (FSM + ALU control + lógica de salto)
 *
 *  NOTAS DE DISEÑO
 *    - A, B, ALUOut y MDR se cargan en TODOS los ciclos (en = 1). No hace
 *      falta habilitarlos porque cada uno se usa solo en el ciclo siguiente
 *      a aquel en que recibe su valor útil. En los estados donde la ALU no
 *      se usa, ALUOut recibe un valor sin significado que nadie lee.
 *    - OldPC existe porque en S0 el PC ya avanza a PC + 4, y los saltos y la
 *      dirección de retorno se calculan con el PC de la instrucción actual.
 *    - jalr no pone en 0 el bit 0 del destino (decisión de diseño, pág. 6 del
 *      diagrama): el código compilado siempre salta a direcciones pares.
 *    - Los nombres de instancias y cables no deben cambiarse: los testbenches
 *      los usan (por ejemplo dut.pc, dut.u_dmem.mem y dut.u_rf.regs).
 * ============================================================================
 */
module cpu_top (
    input clk,
    input reset
);

    // ---- Cables de la ruta de datos (32 bits) --------------------------------
    wire [31:0] pc;            // dirección de la siguiente instrucción a buscar
    wire [31:0] pc_next;       // valor que se cargará en el PC
    wire [31:0] instr_out;     // instrucción leída de la memoria
    wire [31:0] ir;            // instrucción en ejecución (IR)
    wire [31:0] old_pc;        // PC de la instrucción en ejecución (OldPC)
    wire [31:0] rf_rd1;        // registro rs1 leído del banco
    wire [31:0] rf_rd2;        // registro rs2 leído del banco
    wire [31:0] a_out;         // registro A
    wire [31:0] b_out;         // registro B
    wire [31:0] imm;           // inmediato extendido en signo (ImmExt)
    wire [31:0] alu_in_a;      // operando A de la ALU
    wire [31:0] alu_in_b;      // operando B de la ALU
    wire [31:0] alu_result;    // resultado de la ALU en este ciclo (ALUResult)
    wire [31:0] alu_out;       // resultado de la ALU del ciclo anterior (ALUOut)
    wire [31:0] dmem_rdata;    // dato leído de la memoria de datos
    wire [31:0] mdr_out;       // registro MDR
    wire [31:0] reg_wd;        // dato a escribir en rd

    // ---- Campos de la instrucción ---------------------------------------------
    wire [6:0] opcode = ir[6:0];
    wire [4:0] rd     = ir[11:7];
    wire [2:0] funct3 = ir[14:12];
    wire [4:0] rs1    = ir[19:15];
    wire [4:0] rs2    = ir[24:20];

    // ---- Banderas de la ALU (hacia la UC) y señales de control (desde la UC) --
    wire        zero, lt;
    wire        pc_en, pc_src, ir_write, reg_write, mem_read, mem_write;
    wire [1:0]  alu_src_a, alu_src_b, result_src;
    wire [3:0]  alu_ctrl;

    // =========================================================================
    //  FETCH: PC, memoria de instrucciones, IR y OldPC
    // =========================================================================

    // Siguiente PC: PC + 4 (recién calculado por la ALU) o destino de salto
    mux2 #(.WIDTH(32)) u_pcmux (
        .sel (pc_src),
        .d0  (alu_result),
        .d1  (alu_out),
        .y   (pc_next)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_pc (
        .clk (clk), .reset (reset), .en (pc_en), .d (pc_next), .q (pc)
    );

    instr_mem u_imem (
        .addr  (pc),
        .instr (instr_out)
    );

    // IR y OldPC se cargan juntos, solo en S0 (ir_write)
    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_ir (
        .clk (clk), .reset (reset), .en (ir_write), .d (instr_out), .q (ir)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_oldpc (
        .clk (clk), .reset (reset), .en (ir_write), .d (pc), .q (old_pc)
    );

    // =========================================================================
    //  DECODE: banco de registros, registros A y B, generador de inmediatos
    // =========================================================================

    reg_file u_rf (
        .clk   (clk),
        .reset (reset),
        .we    (reg_write),
        .ra1   (rs1),
        .ra2   (rs2),
        .wa    (rd),
        .wd    (reg_wd),
        .rd1   (rf_rd1),
        .rd2   (rf_rd2)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_a (
        .clk (clk), .reset (reset), .en (1'b1), .d (rf_rd1), .q (a_out)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_b (
        .clk (clk), .reset (reset), .en (1'b1), .d (rf_rd2), .q (b_out)
    );

    imm_gen u_imm (
        .instr (ir),
        .imm   (imm)
    );

    // =========================================================================
    //  EXECUTE: selección de operandos, ALU y registro ALUOut
    // =========================================================================

    mux3 #(.WIDTH(32)) u_srca (          // 00 = PC, 01 = OldPC, 10 = A
        .sel (alu_src_a),
        .d0  (pc),
        .d1  (old_pc),
        .d2  (a_out),
        .y   (alu_in_a)
    );

    mux3 #(.WIDTH(32)) u_srcb (          // 00 = B, 01 = inmediato, 10 = 4
        .sel (alu_src_b),
        .d0  (b_out),
        .d1  (imm),
        .d2  (32'd4),
        .y   (alu_in_b)
    );

    alu u_alu (
        .a        (alu_in_a),
        .b        (alu_in_b),
        .alu_ctrl (alu_ctrl),
        .result   (alu_result),
        .zero     (zero),
        .lt       (lt)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_aluout (
        .clk (clk), .reset (reset), .en (1'b1), .d (alu_result), .q (alu_out)
    );

    // =========================================================================
    //  MEMORY: memoria de datos (dirección = ALUOut, dato a guardar = B) y MDR
    // =========================================================================

    data_mem u_dmem (
        .clk       (clk),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .funct3    (funct3),             // tamaño: sb = 1 byte, sw = 4 bytes
        .addr      (alu_out),
        .wdata     (b_out),
        .rdata     (dmem_rdata)
    );

    reg_en #(.WIDTH(32), .RESET_VAL(0)) u_mdr (
        .clk (clk), .reset (reset), .en (1'b1), .d (dmem_rdata), .q (mdr_out)
    );

    // =========================================================================
    //  WRITE-BACK: dato que se escribe en rd
    // =========================================================================

    mux3 #(.WIDTH(32)) u_result (        // 00 = ALUOut, 01 = MDR, 10 = inmediato
        .sel (result_src),
        .d0  (alu_out),
        .d1  (mdr_out),
        .d2  (imm),
        .y   (reg_wd)
    );

    // =========================================================================
    //  UNIDAD DE CONTROL
    // =========================================================================

    control_unit u_ctrl (
        .clk        (clk),
        .reset      (reset),
        .opcode     (opcode),
        .funct3     (funct3),
        .zero       (zero),
        .lt         (lt),
        .pc_en      (pc_en),
        .pc_src     (pc_src),
        .ir_write   (ir_write),
        .reg_write  (reg_write),
        .mem_read   (mem_read),
        .mem_write  (mem_write),
        .alu_src_a  (alu_src_a),
        .alu_src_b  (alu_src_b),
        .result_src (result_src),
        .alu_ctrl   (alu_ctrl)
    );

endmodule
