`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : mux3
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2
 *             (muxes "SrcA", "SrcB" y "ResultSrc")
 *
 *  FUNCIÓN
 *    Multiplexor combinacional de 3 entradas y ancho parametrizable.
 *
 *  RAZÓN DE EXISTENCIA
 *    Permite reutilizar una sola ALU y un solo puerto de escritura del banco
 *    de registros. Se instancia 3 veces en cpu_top:
 *      u_srca   (ALUSrcA)   : 00 = PC      01 = OldPC     10 = A
 *      u_srcb   (ALUSrcB)   : 00 = B       01 = inmediato 10 = constante 4
 *      u_result (ResultSrc) : 00 = ALUOut  01 = MDR       10 = inmediato (lui)
 *
 *  ENTRADAS
 *    sel [1:0]              : selector
 *    d0, d1, d2 [WIDTH-1:0] : datos elegidos con sel = 00, 01 y 10
 *  SALIDAS
 *    y [WIDTH-1:0]          : dato seleccionado; con sel = 11 (no usado) vale 0
 *  PARÁMETROS
 *    WIDTH (32)             : ancho de los datos
 * ============================================================================
 */
module mux3 #(
    parameter WIDTH = 32
)(
    input  [1:0] sel,
    input  [WIDTH-1:0] d0,
    input  [WIDTH-1:0] d1,
    input  [WIDTH-1:0] d2,
    output reg [WIDTH-1:0] y
);

    always @(*) begin
        case (sel)
            2'b00:   y = d0;
            2'b01:   y = d1;
            2'b10:   y = d2;
            default: y = {WIDTH{1'b0}};   // 11 no se usa: salida definida, sin latch
        endcase
    end

endmodule
