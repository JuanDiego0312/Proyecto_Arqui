`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : mux2
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 (mux "PCSrc")
 *
 *  FUNCIÓN
 *    Multiplexor combinacional de 2 entradas y ancho parametrizable.
 *
 *  RAZÓN DE EXISTENCIA
 *    Elige el valor que se cargará en el PC (instancia u_pcmux de cpu_top):
 *      sel = 0 -> ALUResult : PC + 4, en el Fetch (toda instrucción)
 *      sel = 1 -> ALUOut    : destino de salto ya calculado (bne, bge, jal, jalr)
 *
 *  ENTRADAS
 *    sel             : selector
 *    d0 [WIDTH-1:0]  : dato elegido con sel = 0
 *    d1 [WIDTH-1:0]  : dato elegido con sel = 1
 *  SALIDAS
 *    y  [WIDTH-1:0]  : dato seleccionado
 *  PARÁMETROS
 *    WIDTH (32)      : ancho de los datos
 * ============================================================================
 */
module mux2 #(
    parameter WIDTH = 32
)(
    input  sel,
    input  [WIDTH-1:0] d0,
    input  [WIDTH-1:0] d1,
    output [WIDTH-1:0] y
);

    assign y = sel ? d1 : d0;

endmodule
