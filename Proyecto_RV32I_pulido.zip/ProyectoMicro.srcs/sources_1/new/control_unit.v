`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : control_unit   (UNIDAD DE CONTROL)
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2 (recuadro rojo
 *             "Unidad de control")
 *
 *  FUNCIÓN
 *    Unidad de control completa. Solo conecta tres bloques:
 *      u_fsm    : control_fsm   máquina de estados (qué se hace en cada ciclo)
 *      u_aluctl : alu_control   alu_op + funct3 -> operación de la ALU
 *      u_br     : branch_logic  ¿se carga el PC? (saltos condicionales)
 *
 *  RAZÓN DE EXISTENCIA
 *    El enunciado pide que la ruta de datos y la unidad de control sean
 *    identificables. Este módulo es la unidad de control: todo lo que está
 *    dentro del recuadro rojo del diagrama. cpu_top contiene la ruta de datos.
 *
 *  ENTRADAS (vienen de la ruta de datos)
 *    clk, reset      : reloj y reset síncrono activo en alto
 *    opcode  [6:0]   : IR[6:0]
 *    funct3  [2:0]   : IR[14:12]
 *    zero, lt        : banderas de la ALU
 *  SALIDAS (van a la ruta de datos)
 *    pc_en           : habilita la carga del PC = pc_write | (branch & cond)
 *    pc_src          : 0 = PC + 4, 1 = destino de salto (ALUOut)
 *    ir_write        : carga IR y OldPC
 *    reg_write       : escribe en el banco de registros
 *    mem_read        : lee la memoria de datos
 *    mem_write       : escribe la memoria de datos
 *    alu_src_a [1:0] : 00 = PC, 01 = OldPC, 10 = A
 *    alu_src_b [1:0] : 00 = B, 01 = inmediato, 10 = 4
 *    result_src[1:0] : 00 = ALUOut, 01 = MDR, 10 = inmediato
 *    alu_ctrl  [3:0] : 0010 = ADD, 0110 = SUB, 0000 = AND, 0011 = SLL
 *
 *  SEÑALES INTERNAS (no salen del módulo)
 *    pc_write_sig, branch_sig : de la FSM a la lógica de salto
 *    alu_op_sig [1:0]         : de la FSM al ALU control
 * ============================================================================
 */
module control_unit (
    input  clk,
    input  reset,
    input  [6:0] opcode,
    input  [2:0] funct3,
    input  zero,
    input  lt,
    output pc_en,
    output pc_src,
    output ir_write,
    output reg_write,
    output mem_read,
    output mem_write,
    output [1:0] alu_src_a,
    output [1:0] alu_src_b,
    output [1:0] result_src,
    output [3:0] alu_ctrl
);

    wire       pc_write_sig;
    wire       branch_sig;
    wire [1:0] alu_op_sig;

    // Máquina de estados principal
    control_fsm u_fsm (
        .clk        (clk),
        .reset      (reset),
        .opcode     (opcode),
        .pc_write   (pc_write_sig),
        .branch     (branch_sig),
        .pc_src     (pc_src),
        .ir_write   (ir_write),
        .reg_write  (reg_write),
        .mem_read   (mem_read),
        .mem_write  (mem_write),
        .alu_src_a  (alu_src_a),
        .alu_src_b  (alu_src_b),
        .alu_op     (alu_op_sig),
        .result_src (result_src)
    );

    // Operación de la ALU
    alu_control u_aluctl (
        .alu_op   (alu_op_sig),
        .funct3   (funct3),
        .alu_ctrl (alu_ctrl)
    );

    // Habilitación del PC (saltos)
    branch_logic u_br (
        .pc_write (pc_write_sig),
        .branch   (branch_sig),
        .funct3   (funct3),
        .zero     (zero),
        .lt       (lt),
        .pc_en    (pc_en)
    );

    // ------------------------------------------------------------------------
    // AVISOS DE SIMULACIÓN (no generan hardware ni cambian el comportamiento)
    // Si se carga un programa con una instrucción fuera de las 11 soportadas,
    // el procesador no se detiene: la ignora o la ejecuta mal en silencio.
    // Este bloque solo imprime un aviso en la consola para que se note.
    // Se revisa una vez por instrucción, en el flanco que termina S1 (DECODE).
    // ------------------------------------------------------------------------
    // synthesis translate_off
    always @(posedge clk) begin
        if (!reset && u_fsm.current_state == 4'd1) begin      // 4'd1 = S1 (DECODE)
            case (opcode)
                7'b0010011:                                  // tipo I aritmético
                    if (funct3 != 3'b000 && funct3 != 3'b001 && funct3 != 3'b111)
                        $display("[AVISO] t=%0t: funct3 %b no soportado (solo addi, slli, andi)", $time, funct3);
                7'b0000011:                                  // cargas
                    if (funct3 != 3'b010)
                        $display("[AVISO] t=%0t: carga con funct3 %b no soportada (solo lw)", $time, funct3);
                7'b0100011:                                  // almacenamientos
                    if (funct3 != 3'b000 && funct3 != 3'b010)
                        $display("[AVISO] t=%0t: store con funct3 %b no soportado (solo sb, sw)", $time, funct3);
                7'b1100011:                                  // saltos condicionales
                    if (funct3 != 3'b000 && funct3 != 3'b001 && funct3 != 3'b100 && funct3 != 3'b101)
                        $display("[AVISO] t=%0t: salto con funct3 %b no soportado", $time, funct3);
                7'b1101111, 7'b1100111, 7'b0110111: ;        // jal, jalr, lui
                default:
                    $display("[AVISO] t=%0t: opcode %b no soportado; la instruccion se ignora", $time, opcode);
            endcase
        end
    end
    // synthesis translate_on

endmodule
