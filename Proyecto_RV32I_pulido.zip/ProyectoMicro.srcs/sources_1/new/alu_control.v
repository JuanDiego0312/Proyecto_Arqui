`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : alu_control
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, págs. 2 y 6
 *
 *  FUNCIÓN
 *    Decodificador combinacional que traduce la orden general de la FSM
 *    (alu_op) y el campo funct3 de la instrucción en el código de operación
 *    de la ALU (alu_ctrl).
 *
 *  RAZÓN DE EXISTENCIA
 *    addi, andi y slli comparten el mismo opcode (0010011) y solo se
 *    distinguen por funct3. Separar esta decodificación deja la FSM más
 *    simple: la FSM solo dice "suma", "resta" o "lo que diga funct3".
 *
 *  ENTRADAS
 *    alu_op [1:0] : orden de la FSM
 *                     00 = sumar (direcciones, PC + 4, destinos de salto)
 *                     01 = restar (comparación de bne y bge)
 *                     10 = tipo R (reservado; este proyecto no lo usa)
 *                     11 = aritmética tipo I: la operación la define funct3
 *    funct3 [2:0] : IR[14:12]
 *  SALIDAS
 *    alu_ctrl [3:0] : 0010 = ADD, 0110 = SUB, 0000 = AND, 0011 = SLL
 *
 *  TABLA DE VERDAD
 *    alu_op  funct3   alu_ctrl   instrucción
 *      00     xxx     0010 ADD   lw, sw, sb, jal, jalr, PC + 4
 *      01     xxx     0110 SUB   bne, bge
 *      11     000     0010 ADD   addi
 *      11     111     0000 AND   andi
 *      11     001     0011 SLL   slli
 *      otro caso      0010 ADD   (valor seguro por defecto)
 *
 *  NOTA
 *    No se usa el bit 30 de la instrucción: en las instrucciones tipo I ese
 *    bit forma parte del inmediato, así que no puede distinguir operaciones.
 * ============================================================================
 */
module alu_control (
    input  [1:0] alu_op,
    input  [2:0] funct3,
    output reg [3:0] alu_ctrl
);

    // Códigos de operación de la ALU
    localparam [3:0] ALU_AND = 4'b0000,
                     ALU_ADD = 4'b0010,
                     ALU_SLL = 4'b0011,
                     ALU_SUB = 4'b0110;

    // Órdenes de la FSM
    localparam [1:0] OP_ADD   = 2'b00,
                     OP_SUB   = 2'b01,
                     OP_I_ARI = 2'b11;

    always @(*) begin
        alu_ctrl = ALU_ADD;                      // por defecto: sumar
        case (alu_op)
            OP_ADD:   alu_ctrl = ALU_ADD;
            OP_SUB:   alu_ctrl = ALU_SUB;
            OP_I_ARI: begin
                case (funct3)
                    3'b000:  alu_ctrl = ALU_ADD; // addi
                    3'b111:  alu_ctrl = ALU_AND; // andi
                    3'b001:  alu_ctrl = ALU_SLL; // slli
                    default: alu_ctrl = ALU_ADD; // funct3 no soportado
                endcase
            end
            default:  alu_ctrl = ALU_ADD;        // 10 = tipo R reservado
        endcase
    end

endmodule
