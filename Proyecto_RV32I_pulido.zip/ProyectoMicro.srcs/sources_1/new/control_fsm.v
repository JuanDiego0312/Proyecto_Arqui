`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : control_fsm
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, págs. 3 (FSM), 4 (tabla
 *             de estados) y 5 (tabla de señales de control)
 *
 *  FUNCIÓN
 *    Máquina de estados principal de la unidad de control: 12 estados
 *    (S0..S11), salidas tipo Moore (dependen solo del estado actual).
 *    Cada estado dura un ciclo de reloj.
 *
 *  RAZÓN DE EXISTENCIA
 *    En el multiciclo una instrucción se ejecuta en varios pasos. La FSM es
 *    quien decide qué hace cada bloque de la ruta de datos en cada paso. En
 *    S1 mira el opcode y elige el camino de cada tipo de instrucción.
 *
 *  ENTRADAS
 *    clk, reset      : reloj y reset síncrono activo en alto (lleva a S0)
 *    opcode  [6:0]   : IR[6:0]; es estable desde que termina S0
 *  SALIDAS (valen 0 en todo estado que no las necesita)
 *    pc_write        : carga incondicional del PC
 *    branch          : estado de salto condicional (el PC se carga si se
 *                      cumple la condición; lo decide branch_logic)
 *    pc_src          : qué se carga en el PC: 0 = ALUResult (PC + 4),
 *                      1 = ALUOut (destino de salto)
 *    ir_write        : carga IR y OldPC
 *    reg_write       : escribe rd en el banco de registros
 *    mem_read        : lee la memoria de datos
 *    mem_write       : escribe la memoria de datos
 *    alu_src_a [1:0] : operando A de la ALU: 00 = PC, 01 = OldPC, 10 = A
 *    alu_src_b [1:0] : operando B de la ALU: 00 = B, 01 = inmediato, 10 = 4
 *    alu_op    [1:0] : 00 = suma, 01 = resta, 11 = según funct3 (tipo I),
 *                      10 = tipo R (reservado, no se usa)
 *    result_src[1:0] : dato para rd: 00 = ALUOut, 01 = MDR, 10 = inmediato
 *
 *  TABLA DE ESTADOS
 *    Estado          Qué ocurre                                 Siguiente
 *    S0  FETCH       IR <- IMem[PC]; OldPC <- PC; PC <- PC + 4   S1
 *    S1  DECODE      A <- RF[rs1]; B <- RF[rs2];                 según opcode
 *                    ALUOut <- OldPC + Imm
 *    S2  MEM_ADR     ALUOut <- A + Imm                           lw: S3, sw/sb: S5
 *    S3  MEM_READ    MDR <- DMem[ALUOut]                         S4
 *    S4  MEM_WB      RF[rd] <- MDR                               S0
 *    S5  MEM_WRITE   DMem[ALUOut] <- B                           S0
 *    S6  EXEC_I      ALUOut <- A op Imm                          S7
 *    S7  ALU_WB      RF[rd] <- ALUOut                            S0
 *    S8  BRANCH      A - B; si se cumple: PC <- ALUOut           S0
 *    S9  EXEC_JALR   ALUOut <- A + Imm                           S10
 *    S10 JUMP_LINK   PC <- ALUOut; ALUOut <- OldPC + 4           S7
 *    S11 LUI_WB      RF[rd] <- Imm                               S0
 *
 *  CAMINO Y CICLOS POR INSTRUCCIÓN
 *    addi, slli, andi : S0 S1 S6 S7        (4)     bne, bge : S0 S1 S8          (3)
 *    lw               : S0 S1 S2 S3 S4     (5)     jal      : S0 S1 S10 S7      (4)
 *    sw, sb           : S0 S1 S2 S5        (4)     jalr     : S0 S1 S9 S10 S7   (5)
 *    lui              : S0 S1 S11          (3)     opcode desconocido: S0 S1    (2)
 *
 *  NOTAS
 *    - En S1 todavía no se sabe si la instrucción es un salto, pero la ALU
 *      está libre: se adelanta el cálculo OldPC + Imm. Si resulta ser bne,
 *      bge o jal, el destino ya está listo en ALUOut; si no, se descarta.
 *    - jal y jalr comparten S10 y S7: en S10 el PC toma el destino y la ALU
 *      calcula la dirección de retorno; en S7 esa dirección se escribe en rd.
 *    - Un opcode no soportado vuelve a S0 sin hacer nada (equivale a un NOP).
 * ============================================================================
 */
module control_fsm (
    input  clk,
    input  reset,
    input  [6:0] opcode,
    output reg pc_write,
    output reg branch,
    output reg pc_src,
    output reg ir_write,
    output reg reg_write,
    output reg mem_read,
    output reg mem_write,
    output reg [1:0] alu_src_a,
    output reg [1:0] alu_src_b,
    output reg [1:0] alu_op,
    output reg [1:0] result_src
);

    // ---- Estados -----------------------------------------------------------
    localparam [3:0] S0_FETCH     = 4'd0,
                     S1_DECODE    = 4'd1,
                     S2_MEM_ADR   = 4'd2,
                     S3_MEM_READ  = 4'd3,
                     S4_MEM_WB    = 4'd4,
                     S5_MEM_WRITE = 4'd5,
                     S6_EXEC_I    = 4'd6,
                     S7_ALU_WB    = 4'd7,
                     S8_BRANCH    = 4'd8,
                     S9_EXEC_JALR = 4'd9,
                     S10_JUMP_LINK = 4'd10,
                     S11_LUI_WB   = 4'd11;

    // ---- Opcodes soportados (IR[6:0]) ---------------------------------------
    localparam [6:0] OP_I_ARI  = 7'b0010011,   // addi, slli, andi
                     OP_LOAD   = 7'b0000011,   // lw
                     OP_STORE  = 7'b0100011,   // sw, sb
                     OP_BRANCH = 7'b1100011,   // bne, bge
                     OP_JAL    = 7'b1101111,   // jal
                     OP_JALR   = 7'b1100111,   // jalr
                     OP_LUI    = 7'b0110111;   // lui

    // ---- Codificación de los selectores (igual que en el diagrama) ----------
    localparam [1:0] A_PC  = 2'b00, A_OLDPC = 2'b01, A_REG  = 2'b10;   // alu_src_a
    localparam [1:0] B_REG = 2'b00, B_IMM   = 2'b01, B_FOUR = 2'b10;   // alu_src_b
    localparam [1:0] ALU_ADD = 2'b00, ALU_SUB = 2'b01, ALU_FUNCT3 = 2'b11; // alu_op
    localparam [1:0] RES_ALUOUT = 2'b00, RES_MDR = 2'b01, RES_IMM = 2'b10; // result_src

    reg [3:0] current_state, next_state;

    // ---- (1) Registro de estado ---------------------------------------------
    always @(posedge clk) begin
        if (reset) current_state <= S0_FETCH;
        else       current_state <= next_state;
    end

    // ---- (2) Lógica de siguiente estado -------------------------------------
    always @(*) begin
        next_state = S0_FETCH;
        case (current_state)
            S0_FETCH:      next_state = S1_DECODE;
            S1_DECODE: begin                             // el opcode elige el camino
                case (opcode)
                    OP_I_ARI:  next_state = S6_EXEC_I;
                    OP_LOAD:   next_state = S2_MEM_ADR;
                    OP_STORE:  next_state = S2_MEM_ADR;
                    OP_BRANCH: next_state = S8_BRANCH;
                    OP_JAL:    next_state = S10_JUMP_LINK;
                    OP_JALR:   next_state = S9_EXEC_JALR;
                    OP_LUI:    next_state = S11_LUI_WB;
                    default:   next_state = S0_FETCH;    // no soportado: se ignora
                endcase
            end
            S2_MEM_ADR:    next_state = (opcode == OP_LOAD) ? S3_MEM_READ   // lw lee
                                                            : S5_MEM_WRITE; // sw/sb escriben
            S3_MEM_READ:   next_state = S4_MEM_WB;
            S4_MEM_WB:     next_state = S0_FETCH;
            S5_MEM_WRITE:  next_state = S0_FETCH;
            S6_EXEC_I:     next_state = S7_ALU_WB;
            S7_ALU_WB:     next_state = S0_FETCH;
            S8_BRANCH:     next_state = S0_FETCH;
            S9_EXEC_JALR:  next_state = S10_JUMP_LINK;
            S10_JUMP_LINK: next_state = S7_ALU_WB;
            S11_LUI_WB:    next_state = S0_FETCH;
            default:       next_state = S0_FETCH;
        endcase
    end

    // ---- (3) Salidas tipo Moore ----------------------------------------------
    // Primero todo en 0 (ninguna escritura activa, y no se infieren latches);
    // después cada estado activa solo lo que necesita. Las señales marcadas
    // con "X" en la tabla del diagrama (no importa) quedan en 0.
    always @(*) begin
        pc_write   = 1'b0;   branch    = 1'b0;   pc_src    = 1'b0;
        ir_write   = 1'b0;   reg_write = 1'b0;
        mem_read   = 1'b0;   mem_write = 1'b0;
        alu_src_a  = A_PC;   alu_src_b = B_REG;  alu_op    = ALU_ADD;
        result_src = RES_ALUOUT;

        case (current_state)
            S0_FETCH: begin                    // IR <- IMem[PC]; PC <- PC + 4
                ir_write  = 1'b1;
                pc_write  = 1'b1;
                alu_src_a = A_PC;    alu_src_b = B_FOUR;  alu_op = ALU_ADD;
            end
            S1_DECODE: begin                   // ALUOut <- OldPC + Imm
                alu_src_a = A_OLDPC; alu_src_b = B_IMM;   alu_op = ALU_ADD;
            end
            S2_MEM_ADR: begin                  // ALUOut <- A + Imm (dirección)
                alu_src_a = A_REG;   alu_src_b = B_IMM;   alu_op = ALU_ADD;
            end
            S3_MEM_READ: begin                 // MDR <- DMem[ALUOut]
                mem_read = 1'b1;
            end
            S4_MEM_WB: begin                   // RF[rd] <- MDR
                reg_write = 1'b1;    result_src = RES_MDR;
            end
            S5_MEM_WRITE: begin                // DMem[ALUOut] <- B
                mem_write = 1'b1;
            end
            S6_EXEC_I: begin                   // ALUOut <- A op Imm
                alu_src_a = A_REG;   alu_src_b = B_IMM;   alu_op = ALU_FUNCT3;
            end
            S7_ALU_WB: begin                   // RF[rd] <- ALUOut
                reg_write = 1'b1;    result_src = RES_ALUOUT;
            end
            S8_BRANCH: begin                   // A - B; si se cumple, PC <- ALUOut
                branch    = 1'b1;    pc_src = 1'b1;
                alu_src_a = A_REG;   alu_src_b = B_REG;   alu_op = ALU_SUB;
            end
            S9_EXEC_JALR: begin                // ALUOut <- A + Imm (destino)
                alu_src_a = A_REG;   alu_src_b = B_IMM;   alu_op = ALU_ADD;
            end
            S10_JUMP_LINK: begin               // PC <- ALUOut; ALUOut <- OldPC + 4
                pc_write  = 1'b1;    pc_src = 1'b1;
                alu_src_a = A_OLDPC; alu_src_b = B_FOUR;  alu_op = ALU_ADD;
            end
            S11_LUI_WB: begin                  // RF[rd] <- Imm
                reg_write = 1'b1;    result_src = RES_IMM;
            end
            default: ;                         // estados 12..15 no existen
        endcase
    end

endmodule
