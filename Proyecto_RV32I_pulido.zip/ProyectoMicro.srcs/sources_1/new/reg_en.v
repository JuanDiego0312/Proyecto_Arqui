`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : reg_en
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo (Grupo 6)
 *  Diagrama : Microarquitectura_RV32I_Multiciclo.pdf, pág. 2
 *             (bloques PC, IR, OldPC, A, B, ALUOut y MDR)
 *
 *  FUNCIÓN
 *    Registro genérico de WIDTH bits con habilitación de carga y reset síncrono.
 *
 *  RAZÓN DE EXISTENCIA
 *    En el multiciclo cada instrucción tarda varios ciclos, así que hay que
 *    guardar resultados entre un estado y el siguiente. Este único módulo se
 *    instancia 7 veces en cpu_top:
 *      PC     (en = pc_en)     dirección de la siguiente instrucción
 *      IR     (en = ir_write)  instrucción en ejecución
 *      OldPC  (en = ir_write)  PC de la instrucción en ejecución
 *      A, B   (en = 1)         registros rs1 y rs2 leídos del banco
 *      ALUOut (en = 1)         resultado de la ALU del ciclo anterior
 *      MDR    (en = 1)         dato leído de la memoria de datos
 *
 *  ENTRADAS
 *    clk             : reloj (flanco de subida)
 *    reset           : reset síncrono activo en alto; carga RESET_VAL
 *    en              : 1 = carga d en el flanco; 0 = conserva el valor
 *    d  [WIDTH-1:0]  : dato a guardar
 *  SALIDAS
 *    q  [WIDTH-1:0]  : valor guardado
 *  PARÁMETROS
 *    WIDTH     (32)  : ancho del registro
 *    RESET_VAL (0)   : valor que toma q con reset = 1
 * ============================================================================
 */
module reg_en #(
    parameter WIDTH     = 32,
    parameter RESET_VAL = 0
)(
    input  clk,
    input  reset,
    input  en,
    input  [WIDTH-1:0] d,
    output reg [WIDTH-1:0] q
);

    always @(posedge clk) begin
        if (reset)
            q <= RESET_VAL;      // el reset tiene prioridad sobre la carga
        else if (en)
            q <= d;              // sin habilitación, q conserva su valor
    end

endmodule
