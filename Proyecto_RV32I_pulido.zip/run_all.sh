#!/bin/sh
# Corre los 14 testbenches con Icarus Verilog (alternativa rápida a Vivado).
# Uso:  sh run_all.sh      (desde la carpeta donde está este archivo)
SRC=ProyectoMicro.srcs/sources_1/new
SIM=ProyectoMicro.srcs/sim_1/new
cp $SIM/programa.hex $SIM/programa_link.hex .
for t in mux2 mux3 reg_en alu alu_control imm_gen branch_logic reg_file \
         instr_mem data_mem control_fsm control_unit cpu_top cpu_top_link; do
    echo "######## ${t}_tb"
    iverilog -g2001 -s ${t}_tb -o ${t}.vvp $SRC/*.v $SIM/${t}_tb.v && vvp -n ${t}.vvp
    rm -f ${t}.vvp
done
