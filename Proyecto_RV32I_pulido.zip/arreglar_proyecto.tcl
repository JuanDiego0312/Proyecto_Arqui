# ==============================================================================
#  arreglar_proyecto.tcl  -  MT-7003, proyecto RV32I multiciclo (Grupo 6)
#  Uso: abrir ProyectoMicro.xpr en Vivado y, en la consola Tcl, escribir:
#           source C:/ruta/a/arreglar_proyecto.tcl
#  Qué hace (solo configuración del proyecto; no toca el código):
#    1. Quita los archivos vacíos mux2.v y mux3.v de las fuentes de simulación.
#    2. Quita la referencia a programa.hex fuera del proyecto (carpeta Downloads).
#    3. Agrega los testbenches que faltan y los .hex que están dentro del proyecto.
#    4. Sube el tiempo de simulación a 3 us (cpu_top_tb necesita 1.9 us).
#  NOTA: probado solo por lectura; si algún paso falla, hágalo a mano (LEEME.txt).
# ==============================================================================
set proj_dir [get_property DIRECTORY [current_project]]
set sim_dir  "$proj_dir/ProyectoMicro.srcs/sim_1/new"

# 1. Archivos vacíos creados por error en sim_1
foreach f {mux2.v mux3.v} {
    set obj [get_files -quiet "$sim_dir/$f"]
    if {[llength $obj] > 0} { remove_files -fileset sim_1 $obj }
    file delete -force "$sim_dir/$f"
}

# 2. programa.hex enlazado desde fuera del proyecto
set old_hex [get_files -quiet -of_objects [get_filesets sim_1] *programa.hex]
if {[llength $old_hex] > 0} { remove_files -fileset sim_1 $old_hex }

# 3. Testbenches y programas que deben estar en el proyecto
add_files -fileset sim_1 -norecurse [list \
    "$sim_dir/control_unit_tb.v" \
    "$sim_dir/cpu_top_link_tb.v" \
    "$sim_dir/programa.hex" \
    "$sim_dir/programa_link.hex"]

# 4. Tiempo de simulación
set_property -name {xsim.simulate.runtime} -value {3us} -objects [get_filesets sim_1]

update_compile_order -fileset sources_1
update_compile_order -fileset sim_1
puts "Listo: proyecto corregido. Simulation Sources debe mostrar 14 testbenches."
