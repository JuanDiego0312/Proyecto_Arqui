`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : reg_en
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Registro genérico con habilitación de carga y reset síncrono.
 *  Razón de existencia:
 *    El multiciclo necesita guardar resultados entre estados. Este único
 *    módulo se instancia 7 veces en cpu_top:
 *      PC     (en = pc_en)       IR   (en = ir_write)    OldPC (en = ir_write)
 *      A, B, ALUOut, MDR (en = 1'b1: se cargan en cada ciclo)
 *
 *  ENTRADAS
 *    clk          : reloj (flanco de subida)
 *    reset        : reset síncrono activo en alto; carga RESET_VAL
 *    en           : habilitación; 1 = carga d en el flanco, 0 = conserva q
 *    d  [WIDTH-1:0]: dato a almacenar
 *  SALIDAS
 *    q  [WIDTH-1:0]: valor almacenado
 *  PARÁMETROS
 *    WIDTH     (32): ancho del registro
 *    RESET_VAL (0) : valor que toma q con reset = 1
 * ============================================================================
 */
module reg_en #(
    parameter WIDTH = 32,
    parameter RESET_VAL = 0
)(
    input  clk,
    input  reset,
    input  en,
    input  [WIDTH-1:0] d,
    output reg [WIDTH-1:0] q
);

    always @(posedge clk) begin
        if (reset)
            q <= RESET_VAL;      // el reset tiene prioridad sobre la carga
        else if (en)
            q <= d;              // carga solo si está habilitado
    end

endmodule
