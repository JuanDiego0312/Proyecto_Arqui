`timescale 1ns/1ps

/*
 * Módulo: imm_gen
 * Función: Generador de inmediatos (ImmGen) con extensión de signo según el formato de la instrucción RISC-V.
 * Razón de existencia: Diferentes tipos de instrucciones (I, S, B, U, J) ubican los bits inmediatos
 *   en posiciones distintas, requiriendo extracción y extensión de signo adecuada.
 * 
 * Tabla de ENTRADAS:
 *   - instr [31:0] : Instrucción completa de 32 bits (IR)
 * 
 * Tabla de SALIDAS:
 *   - imm [31:0]   : Inmediato extendido en signo de 32 bits
 */
module imm_gen (
    input  [31:0] instr,
    output reg [31:0] imm
);

    wire [6:0] opcode = instr[6:0];

    always @(*) begin
        imm = 32'b0;
        case (opcode)
            7'b0010011, 7'b0000011, 7'b1100111:
                imm = {{20{instr[31]}}, instr[31:20]};
            7'b0100011:
                imm = {{20{instr[31]}}, instr[31:25], instr[11:7]};
            7'b1100011:
                imm = {{19{instr[31]}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0};
            7'b0110111:
                imm = {instr[31:12], 12'b0};
            7'b1101111:
                imm = {{11{instr[31]}}, instr[31], instr[19:12], instr[20], instr[30:21], 1'b0};
            default:
                imm = 32'b0;
        endcase
    end

endmodule