`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : mux2
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Multiplexor de 2 entradas de ancho parametrizable (combinacional).
 *  Razón de existencia:
 *    Elige el valor del siguiente PC (señal PCSrc):
 *      PCSrc = 0 -> ALUResult (PC + 4, usado en el Fetch)
 *      PCSrc = 1 -> ALUOut    (destino de bne/bge/jal/jalr calculado antes)
 *
 *  ENTRADAS
 *    sel          [0]       : selector (0 = d0, 1 = d1)
 *    d0           [WIDTH-1:0]: dato elegido cuando sel = 0
 *    d1           [WIDTH-1:0]: dato elegido cuando sel = 1
 *  SALIDAS
 *    y            [WIDTH-1:0]: dato seleccionado
 *  PARÁMETROS
 *    WIDTH (32)   : ancho de los datos
 * ============================================================================
 */
module mux2 #(parameter WIDTH = 32)(
    input  sel,
    input  [WIDTH-1:0] d0,
    input  [WIDTH-1:0] d1,
    output [WIDTH-1:0] y
);
    assign y = sel ? d1 : d0;
endmodule
