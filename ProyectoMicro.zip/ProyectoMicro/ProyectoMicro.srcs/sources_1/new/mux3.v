`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : mux3
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Multiplexor de 3 entradas de ancho parametrizable (combinacional).
 *  Razón de existencia (se instancia 3 veces en cpu_top):
 *    - u_srca  (ALUSrcA)  : 00 = PC, 01 = OldPC, 10 = A
 *    - u_srcb  (ALUSrcB)  : 00 = B,  01 = ImmExt, 10 = constante 4
 *    - u_result(ResultSrc): 00 = ALUOut, 01 = MDR, 10 = ImmExt (lui)
 *    Permite reutilizar una sola ALU y un solo puerto de escritura del banco
 *    de registros en estados distintos de la FSM.
 *
 *  ENTRADAS
 *    sel          [1:0]       : selector (00 = d0, 01 = d1, 10 = d2)
 *    d0, d1, d2   [WIDTH-1:0] : datos de entrada
 *  SALIDAS
 *    y            [WIDTH-1:0] : dato seleccionado; con sel = 11 vale 0
 *  PARÁMETROS
 *    WIDTH (32)   : ancho de los datos
 * ============================================================================
 */
module mux3 #(parameter WIDTH = 32)(
    input  [1:0] sel,
    input  [WIDTH-1:0] d0,
    input  [WIDTH-1:0] d1,
    input  [WIDTH-1:0] d2,
    output reg [WIDTH-1:0] y
);
    always @(*) begin
        case (sel)
            2'b00:   y = d0;
            2'b01:   y = d1;
            2'b10:   y = d2;
            default: y = {WIDTH{1'b0}};   // sel = 11 no se usa: salida en 0
        endcase
    end
endmodule
