`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : cpu_top
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Módulo superior del procesador. Conecta la ruta de datos y la
 *             unidad de control. Soporta addi, slli, andi, lw, sw, sb, bne,
 *             bge, jal, jalr y lui.
 *  Razón de existencia:
 *    Es el circuito completo. Posee EXCLUSIVAMENTE dos entradas: clk y reset
 *    (el único cambio permitido en la evaluación es el contenido de instr_mem).
 *
 *  ENTRADAS
 *    clk   : reloj del sistema
 *    reset : reset síncrono activo en alto (PC = 0, FSM en S0, x2 = 0x100)
 *  SALIDAS
 *    ninguna
 *
 *  BLOQUES (nombres de instancia)
 *    Registros : u_pc (PC), u_ir (IR), u_oldpc (OldPC), u_a (A), u_b (B),
 *                u_aluout (ALUOut), u_mdr (MDR)
 *    Memorias  : u_imem (instrucciones), u_dmem (datos)
 *    Datos     : u_rf (banco de registros), u_imm (ImmGen), u_alu (ALU)
 *    Muxes     : u_pcmux (PCSrc), u_srca (ALUSrcA), u_srcb (ALUSrcB), u_result (ResultSrc)
 *    Control   : u_ctrl (FSM + ALU control + lógica de salto)
 * ============================================================================
 */
module cpu_top (
    input clk,
    input reset
);

    // --- Cables de la ruta de datos (32 bits) ---
    wire [31:0] pc, pc_next, ir, old_pc, instr_out;
    wire [31:0] rf_rd1, rf_rd2, a_out, b_out, imm;
    wire [31:0] alu_in_a, alu_in_b, alu_result, alu_out;
    wire [31:0] dmem_rdata, mdr_out, reg_wd;
    // --- Banderas de la ALU y señales de control ---
    wire        zero, lt;
    wire        pc_en, pc_src, ir_write, reg_write, mem_read, mem_write;
    wire [1:0]  alu_src_a, alu_src_b, result_src;
    wire [3:0]  alu_ctrl;

    // Fetch: PC, selección del siguiente PC, memoria de instrucciones, IR y OldPC
    mux2 #(32)  u_pcmux  (.sel(pc_src), .d0(alu_result), .d1(alu_out), .y(pc_next));
    reg_en #(32,0) u_pc  (.clk(clk), .reset(reset), .en(pc_en), .d(pc_next), .q(pc));

    instr_mem    u_imem  (.addr(pc), .instr(instr_out));
    reg_en #(32,0) u_ir  (.clk(clk), .reset(reset), .en(ir_write), .d(instr_out), .q(ir));
    reg_en #(32,0) u_oldpc (.clk(clk), .reset(reset), .en(ir_write), .d(pc), .q(old_pc));

    // Decode: banco de registros (campos rs1, rs2, rd del IR), registros A y B e inmediato
    reg_file     u_rf    (.clk(clk), .reset(reset), .we(reg_write),
                          .ra1(ir[19:15]), .ra2(ir[24:20]), .wa(ir[11:7]), .wd(reg_wd),
                          .rd1(rf_rd1), .rd2(rf_rd2));

    reg_en #(32,0) u_a   (.clk(clk), .reset(reset), .en(1'b1), .d(rf_rd1), .q(a_out));
    reg_en #(32,0) u_b   (.clk(clk), .reset(reset), .en(1'b1), .d(rf_rd2), .q(b_out));

    imm_gen      u_imm   (.instr(ir), .imm(imm));

    // Execute: entradas de la ALU, ALU y registro ALUOut
    mux3 #(32)   u_srca  (.sel(alu_src_a), .d0(pc), .d1(old_pc), .d2(a_out), .y(alu_in_a));
    mux3 #(32)   u_srcb  (.sel(alu_src_b), .d0(b_out), .d1(imm), .d2(32'd4), .y(alu_in_b));

    alu          u_alu   (.a(alu_in_a), .b(alu_in_b), .alu_ctrl(alu_ctrl),
                          .result(alu_result), .zero(zero), .lt(lt));

    reg_en #(32,0) u_aluout (.clk(clk), .reset(reset), .en(1'b1), .d(alu_result), .q(alu_out));

    // Memory: memoria de datos (dirección = ALUOut, dato a guardar = B) y MDR
    data_mem     u_dmem  (.clk(clk), .mem_read(mem_read), .mem_write(mem_write),
                          .funct3(ir[14:12]), .addr(alu_out), .wdata(b_out), .rdata(dmem_rdata));

    reg_en #(32,0) u_mdr (.clk(clk), .reset(reset), .en(1'b1), .d(dmem_rdata), .q(mdr_out));

    // Write-back: dato que se escribe en rd
    mux3 #(32)   u_result (.sel(result_src), .d0(alu_out), .d1(mdr_out), .d2(imm), .y(reg_wd));

    // Unidad de control: FSM + ALU control + lógica de salto
    control_unit u_ctrl  (.clk(clk), .reset(reset), .opcode(ir[6:0]), .funct3(ir[14:12]),
                          .zero(zero), .lt(lt), .pc_en(pc_en), .pc_src(pc_src),
                          .ir_write(ir_write), .reg_write(reg_write), .mem_read(mem_read),
                          .mem_write(mem_write), .alu_src_a(alu_src_a), .alu_src_b(alu_src_b),
                          .result_src(result_src), .alu_ctrl(alu_ctrl));

endmodule
