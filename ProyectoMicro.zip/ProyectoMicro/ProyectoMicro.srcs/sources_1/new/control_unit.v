`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : control_unit
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Envoltorio de la unidad de control: integra la FSM principal,
 *             el ALU control y la lógica de salto.
 *  Razón de existencia:
 *    Agrupa en un solo bloque todo lo que el diagrama muestra dentro del
 *    recuadro "Unidad de Control", de modo que cpu_top solo conecta señales.
 *
 *  ENTRADAS
 *    clk, reset      : reloj y reset síncrono
 *    opcode  [6:0]   : IR[6:0] (para la FSM)
 *    funct3  [2:0]   : IR[14:12] (para ALU control y lógica de salto)
 *    zero, lt        : banderas de la ALU (para la lógica de salto)
 *  SALIDAS
 *    pc_en           : habilitación del PC = pc_write | (branch & cond)
 *    pc_src, ir_write, reg_write, mem_read, mem_write
 *    alu_src_a [1:0], alu_src_b [1:0], result_src [1:0]
 *    alu_ctrl  [3:0] : operación de la ALU (0010 ADD, 0110 SUB, 0000 AND, 0011 SLL)
 *
 *  INSTANCIAS INTERNAS
 *    u_fsm    : control_fsm   (genera pc_write, branch y alu_op como señales internas)
 *    u_aluctl : alu_control   (alu_op + funct3 -> alu_ctrl)
 *    u_br     : branch_logic  (pc_write, branch, funct3, zero, lt -> pc_en)
 * ============================================================================
 */
module control_unit (
    input  clk,
    input  reset,
    input  [6:0] opcode,
    input  [2:0] funct3,
    input  zero,
    input  lt,
    output pc_en,
    output pc_src,
    output ir_write,
    output reg_write,
    output mem_read,
    output mem_write,
    output [1:0] alu_src_a,
    output [1:0] alu_src_b,
    output [1:0] result_src,
    output [3:0] alu_ctrl
);

    // Señales internas entre la FSM y los demás bloques de control
    wire pc_write_sig, branch_sig;
    wire [1:0] alu_op_sig;

    control_fsm u_fsm (.clk(clk), .reset(reset), .opcode(opcode), .pc_write(pc_write_sig),
                       .branch(branch_sig), .pc_src(pc_src), .ir_write(ir_write), .reg_write(reg_write),
                       .mem_read(mem_read), .mem_write(mem_write), .alu_src_a(alu_src_a),
                       .alu_src_b(alu_src_b), .alu_op(alu_op_sig), .result_src(result_src));

    alu_control u_aluctl (.alu_op(alu_op_sig), .funct3(funct3), .alu_ctrl(alu_ctrl));

    branch_logic u_br (.pc_write(pc_write_sig), .branch(branch_sig), .funct3(funct3),
                       .zero(zero), .lt(lt), .pc_en(pc_en));

endmodule
