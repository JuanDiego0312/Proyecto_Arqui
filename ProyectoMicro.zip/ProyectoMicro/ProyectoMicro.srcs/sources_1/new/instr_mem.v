`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : instr_mem
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Memoria de instrucciones de solo lectura con lectura combinacional.
 *  Razón de existencia:
 *    Guarda el programa compilado (programa.hex). Es el ÚNICO componente que
 *    se modifica durante la evaluación (cambiando el archivo .hex cargado).
 *
 *  ENTRADAS
 *    addr  [31:0] : dirección en BYTES (el PC); los 2 bits bajos se ignoran
 *  SALIDAS
 *    instr [31:0] : instrucción de la palabra addr[31:2]; 0 si está fuera de rango
 *  PARÁMETROS
 *    WORDS    (256)            : número de palabras de 32 bits
 *    HEX_FILE ("programa.hex") : una palabra de 32 bits por línea, 8 dígitos hex
 *                                sin prefijo; la línea 1 es la dirección 0
 *  Notas:
 *    - Las palabras no cubiertas por el archivo quedan en 0.
 *    - $readmemh avisa "Not enough words" si el .hex tiene menos de WORDS líneas:
 *      es normal.
 *    - En Vivado, agregar programa.hex como archivo de simulación o usar ruta
 *      absoluta en HEX_FILE.
 * ============================================================================
 */
module instr_mem #(
    parameter WORDS = 256,
    parameter HEX_FILE = "programa.hex"
)(
    input  [31:0] addr,
    output [31:0] instr
);

    reg [31:0] mem [0:WORDS-1];
    integer i;

    initial begin
        for (i = 0; i < WORDS; i = i + 1) mem[i] = 32'b0;   // memoria limpia
        $readmemh(HEX_FILE, mem);                            // carga el programa
    end

    // Índice de palabra: la dirección en bytes dividida entre 4
    wire [31:0] word_addr = addr >> 2;
    assign instr = (word_addr < WORDS) ? mem[word_addr[31:0]] : 32'b0;

endmodule
