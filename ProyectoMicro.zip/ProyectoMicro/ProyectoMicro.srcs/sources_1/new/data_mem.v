`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : data_mem
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Memoria de datos de 2^ADDR_BITS bytes: lectura combinacional
 *             (controlada por mem_read) y escritura síncrona por byte o palabra.
 *  Razón de existencia:
 *    lw/sw acceden 4 bytes y sb escribe 1 byte en una dirección que no está
 *    alineada (sb a5,-29(s0) escribe en 0xE3). Incluye el task obligatorio
 *    dump_memory para el volcado de memoria que pide el enunciado.
 *
 *  ENTRADAS
 *    clk            : reloj (la escritura ocurre en el flanco de subida)
 *    mem_read       : 1 = rdata entrega la palabra de la dirección; 0 = rdata = 0
 *    mem_write      : 1 = escribe en el flanco de subida
 *    funct3  [2:0]  : tamaño del acceso: 000 = sb (1 byte), 010 = sw (4 bytes);
 *                     otros valores no escriben
 *    addr   [31:0]  : dirección en bytes (solo se usan los ADDR_BITS bajos)
 *    wdata  [31:0]  : dato a escribir (sb usa wdata[7:0])
 *  SALIDAS
 *    rdata  [31:0]  : palabra de 4 bytes little-endian en la dirección alineada
 *  PARÁMETROS
 *    ADDR_BITS (8)  : 2^8 = 256 bytes (la pila usa 0xE0 .. 0xFC)
 *  TASK
 *    dump_memory(filename): escribe el archivo con la línea de encabezado y
 *    una línea "0xDIR 0xVALOR" por cada palabra de 4 bytes. Se invoca desde un
 *    testbench por referencia jerárquica: dut.u_dmem.dump_memory("memory_dump.txt");
 * ============================================================================
 */
module data_mem #(
    parameter ADDR_BITS = 8
)(
    input  clk,
    input  mem_read,
    input  mem_write,
    input  [2:0] funct3,
    input  [31:0] addr,
    input  [31:0] wdata,
    output [31:0] rdata
);

    reg [7:0] mem [0:(1<<ADDR_BITS)-1];
    integer i;

    initial begin
        for (i = 0; i < (1<<ADDR_BITS); i = i + 1) mem[i] = 8'b0;
    end

    // Índice del byte accedido y de la palabra alineada que lo contiene
    wire [ADDR_BITS-1:0] index = addr[ADDR_BITS-1:0];
    wire [ADDR_BITS-1:0] aligned_index = {index[ADDR_BITS-1:2], 2'b00};

    // Lectura: palabra little-endian (el byte de menor dirección es el menos significativo)
    assign rdata = mem_read ? {mem[aligned_index+3], mem[aligned_index+2], mem[aligned_index+1], mem[aligned_index]} : 32'b0;

    // Escritura síncrona
    always @(posedge clk) begin
        if (mem_write) begin
            case (funct3)
                3'b000: mem[index] <= wdata[7:0];   // sb: solo ese byte, aunque no esté alineado
                3'b010: begin                       // sw: 4 bytes en la dirección alineada
                    mem[aligned_index]   <= wdata[7:0];
                    mem[aligned_index+1] <= wdata[15:8];
                    mem[aligned_index+2] <= wdata[23:16];
                    mem[aligned_index+3] <= wdata[31:24];
                end
                default: ;                          // otros tamaños: no se escribe
            endcase
        end
    end

    // Volcado de memoria: una línea por palabra con el formato "0xDIR 0xVALOR"
    task dump_memory;
        input [8*40-1:0] filename;
        integer file_id;
        integer addr_idx;
        begin
            file_id = $fopen(filename, "w");
            if (file_id) begin
                $fwrite(file_id, "Direccion de Memoria    Valor en hexadecimal\n");
                for (addr_idx = 0; addr_idx < (1<<ADDR_BITS); addr_idx = addr_idx + 4) begin
                    $fwrite(file_id, "0x%0X    0x%02X%02X%02X%02X\n",
                        addr_idx, mem[addr_idx+3], mem[addr_idx+2], mem[addr_idx+1], mem[addr_idx+0]);
                end
                $fclose(file_id);
                $display("[INFO] Volcado de memoria completado en: %0s", filename);
            end
        end
    endtask

endmodule
