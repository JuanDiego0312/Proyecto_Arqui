`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : branch_logic
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Genera la habilitación del PC (pc_en) combinando las cargas
 *             incondicionales de la FSM con la condición de los saltos.
 *  Razón de existencia:
 *    bne salta si rs1 != rs2 (Zero = 0) y bge salta si rs1 >= rs2 con signo
 *    (LT = 0). La FSM solo indica "estoy en un salto" (branch); esta lógica
 *    decide si realmente se carga el PC.
 *
 *  ENTRADAS
 *    pc_write     : carga incondicional del PC (S0 y S10)
 *    branch       : 1 en el estado S8 (salto condicional)
 *    funct3 [2:0] : IR[14:12]; 000 beq, 001 bne, 100 blt, 101 bge
 *    zero         : bandera de la ALU, 1 si A - B = 0
 *    lt           : bandera de la ALU, 1 si A < B (con signo)
 *  SALIDAS
 *    pc_en        : 1 = el PC se carga en el próximo flanco de reloj
 *
 *  Comportamiento:  pc_en = pc_write | (branch & cond)
 *    cond = zero (beq) | ~zero (bne) | lt (blt) | ~lt (bge) | 0 (otro funct3)
 * ============================================================================
 */
module branch_logic (
    input  pc_write,
    input  branch,
    input  [2:0] funct3,
    input  zero,
    input  lt,
    output pc_en
);

    reg cond;

    always @(*) begin
        case (funct3)
            3'b000: cond = zero;     // beq
            3'b001: cond = ~zero;    // bne
            3'b100: cond = lt;       // blt
            3'b101: cond = ~lt;      // bge
            default: cond = 1'b0;
        endcase
    end

    assign pc_en = pc_write | (branch & cond);

endmodule
