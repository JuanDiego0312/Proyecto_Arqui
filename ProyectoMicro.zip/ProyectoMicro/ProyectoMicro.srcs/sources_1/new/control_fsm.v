`timescale 1ns/1ps

/*
 * ============================================================================
 *  Módulo   : control_fsm
 *  Proyecto : MT-7003 - Microarquitectura RISC-V RV32I multiciclo
 *  Función  : Máquina de estados de 12 estados (S0..S11) con salidas tipo Moore.
 *             Cada estado dura un ciclo de reloj y activa las señales que
 *             necesita la ruta de datos en ese paso.
 *  Razón de existencia:
 *    Es el "director" del multiciclo: decide qué hace cada bloque en cada ciclo.
 *    En S1 lee el opcode y elige el camino de cada familia de instrucciones.
 *
 *  ENTRADAS
 *    clk, reset      : reloj y reset síncrono activo en alto (lleva a S0)
 *    opcode  [6:0]   : IR[6:0], estable desde el final de S0
 *  SALIDAS (todas 0 salvo las indicadas en cada estado)
 *    pc_write   : carga incondicional del PC
 *    branch     : estado de salto condicional (el PC se carga si se cumple la condición)
 *    pc_src     : 0 = ALUResult (PC+4), 1 = ALUOut (destino de salto)
 *    ir_write   : carga IR y OldPC
 *    reg_write  : escribe en el banco de registros
 *    mem_read / mem_write : lectura / escritura de la memoria de datos
 *    alu_src_a [1:0] : 00 = PC, 01 = OldPC, 10 = A
 *    alu_src_b [1:0] : 00 = B,  01 = ImmExt, 10 = constante 4
 *    alu_op    [1:0] : 00 = suma, 01 = resta, 10 = tipo R (reservado), 11 = I-aritmética
 *    result_src[1:0] : 00 = ALUOut, 01 = MDR, 10 = ImmExt
 *
 *  TABLA DE ESTADOS
 *   Estado       Transferencia de registros                    Siguiente
 *   S0  FETCH      IR<=IMem[PC]; OldPC<=PC; PC<=PC+4            S1
 *   S1  DECODE     A<=RF[rs1]; B<=RF[rs2]; ALUOut<=OldPC+Imm    según opcode
 *   S2  MEM_ADR    ALUOut<=A+Imm                                lw: S3 ; sw/sb: S5
 *   S3  MEM_READ   MDR<=DMem[ALUOut]                            S4
 *   S4  MEM_WB     RF[rd]<=MDR                                  S0
 *   S5  MEM_WRITE  DMem[ALUOut]<=B                              S0
 *   S6  EXEC_I     ALUOut<=A op Imm                             S7
 *   S7  ALU_WB     RF[rd]<=ALUOut                               S0
 *   S8  BRANCH     A-B; si cond: PC<=ALUOut                     S0
 *   S9  EXEC_JALR  ALUOut<=A+Imm                                S10
 *   S10 JUMP_LINK  PC<=ALUOut; ALUOut<=OldPC+4                  S7
 *   S11 LUI_WB     RF[rd]<=ImmExt                               S0
 *
 *  SELECCIÓN DE CAMINO EN S1 (opcode)
 *   0010011 (addi, slli, andi) -> S6     0000011 (lw)      -> S2
 *   0100011 (sw, sb)           -> S2     1100011 (bne,bge) -> S8
 *   1101111 (jal)              -> S10    1100111 (jalr)    -> S9
 *   0110111 (lui)              -> S11    otro              -> S0
 * ============================================================================
 */
module control_fsm (
    input  clk,
    input  reset,
    input  [6:0] opcode,
    output reg pc_write,
    output reg branch,
    output reg pc_src,
    output reg ir_write,
    output reg reg_write,
    output reg mem_read,
    output reg mem_write,
    output reg [1:0] alu_src_a,
    output reg [1:0] alu_src_b,
    output reg [1:0] alu_op,
    output reg [1:0] result_src
);

    localparam [3:0]
        S0=0, S1=1, S2=2, S3=3, S4=4, S5=5, S6=6, S7=7, S8=8, S9=9, S10=10, S11=11;

    reg [3:0] current_state, next_state;

    // (1) Registro de estado: reset síncrono a S0
    always @(posedge clk) begin
        if (reset) current_state <= S0;
        else current_state <= next_state;
    end

    // (2) Lógica de siguiente estado
    always @(*) begin
        next_state = S0;
        case (current_state)
            S0: next_state = S1;
            S1: begin                                   // el opcode elige el camino
                case (opcode)
                    7'b0010011: next_state = S6;        // addi, slli, andi
                    7'b0000011: next_state = S2;        // lw
                    7'b0100011: next_state = S2;        // sw, sb
                    7'b1100011: next_state = S8;        // bne, bge
                    7'b1101111: next_state = S10;       // jal
                    7'b1100111: next_state = S9;        // jalr
                    7'b0110111: next_state = S11;       // lui
                    default:    next_state = S0;
                endcase
            end
            S2:  next_state = (opcode == 7'b0000011) ? S3 : S5;   // lw lee, sw/sb escribe
            S3:  next_state = S4;
            S4:  next_state = S0;
            S5:  next_state = S0;
            S6:  next_state = S7;
            S7:  next_state = S0;
            S8:  next_state = S0;
            S9:  next_state = S10;
            S10: next_state = S7;
            S11: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // (3) Salidas tipo Moore: dependen solo del estado actual
    always @(*) begin
        // Valores por defecto: ninguna escritura activa (evita latches)
        pc_write = 0; branch = 0; pc_src = 0; ir_write = 0; reg_write = 0;
        mem_read = 0; mem_write = 0; alu_src_a = 0; alu_src_b = 0; alu_op = 0; result_src = 0;

        case (current_state)
            S0:  begin pc_write=1; ir_write=1; alu_src_a=2'b00; alu_src_b=2'b10; alu_op=2'b00; end  // PC+4
            S1:  begin alu_src_a=2'b01; alu_src_b=2'b01; alu_op=2'b00; end                           // OldPC+Imm
            S2:  begin alu_src_a=2'b10; alu_src_b=2'b01; alu_op=2'b00; end                           // A+Imm
            S3:  begin mem_read=1; end
            S4:  begin reg_write=1; result_src=2'b01; end                                            // MDR
            S5:  begin mem_write=1; end
            S6:  begin alu_src_a=2'b10; alu_src_b=2'b01; alu_op=2'b11; end                           // A op Imm
            S7:  begin reg_write=1; result_src=2'b00; end                                            // ALUOut
            S8:  begin branch=1; pc_src=1; alu_src_a=2'b10; alu_src_b=2'b00; alu_op=2'b01; end       // A-B
            S9:  begin alu_src_a=2'b10; alu_src_b=2'b01; alu_op=2'b00; end                           // A+Imm
            S10: begin pc_write=1; pc_src=1; alu_src_a=2'b01; alu_src_b=2'b10; alu_op=2'b00; end     // OldPC+4
            S11: begin reg_write=1; result_src=2'b10; end                                            // ImmExt
            default: ;
        endcase
    end

endmodule
