`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : reg_en_tb
 *  Módulo bajo prueba : reg_en (dos instancias: 32 bits con RESET_VAL = 0 y
 *                       8 bits con RESET_VAL = 8'hA5)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar el reset síncrono (con su valor parametrizable), la carga con
 *    en = 1, la retención con en = 0 y que el reset tenga prioridad sobre en.
 *
 *  ESTÍMULOS
 *    1. reset = 1 por 2 flancos.
 *    2. en = 1 y d = 0xDEADBEEF / 8'h3C; esperar un flanco.
 *    3. en = 0 y cambiar d; esperar un flanco.
 *    4. reset = 1 con en = 1.
 *
 *  RESULTADOS ESPERADOS
 *    Tras el reset: q32 = 0 y q8 = 0xA5. Tras cargar: q32 = 0xDEADBEEF y
 *    q8 = 0x3C. Con en = 0 conservan el valor. Con reset vuelven al valor de reset.
 * ============================================================================
 */
module reg_en_tb;

    reg clk, reset, en;
    reg [31:0] d32;
    reg [7:0]  d8;
    wire [31:0] q32;
    wire [7:0]  q8;
    integer errors;

    reg_en #(.WIDTH(32), .RESET_VAL(0))        dut32 (.clk(clk), .reset(reset), .en(en), .d(d32), .q(q32));
    reg_en #(.WIDTH(8),  .RESET_VAL(8'hA5))    dut8  (.clk(clk), .reset(reset), .en(en), .d(d8),  .q(q8));

    always #5 clk = ~clk;

    task check;
        input [8*40-1:0] name;
        input [31:0] got;
        input [31:0] expected;
        begin
            if (got === expected) $display("[PASS] %0s = 0x%X", name, got);
            else begin
                $display("[FAIL] %0s = 0x%X (esperado 0x%X)", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE REG_EN ===");
        clk = 0; reset = 1; en = 0; d32 = 0; d8 = 0;
        @(posedge clk); @(posedge clk); #1;
        check("reset q32", q32, 32'h0);
        check("reset q8 (RESET_VAL=A5)", q8, 32'hA5);

        reset = 0; en = 1; d32 = 32'hDEADBEEF; d8 = 8'h3C; @(posedge clk); #1;
        check("carga q32", q32, 32'hDEADBEEF);
        check("carga q8",  q8,  32'h3C);

        en = 0; d32 = 32'h11111111; d8 = 8'hFF; @(posedge clk); #1;
        check("retiene q32 con en=0", q32, 32'hDEADBEEF);
        check("retiene q8 con en=0",  q8,  32'h3C);

        en = 1; reset = 1; @(posedge clk); #1;
        check("reset gana sobre en q32", q32, 32'h0);
        check("reset gana sobre en q8",  q8,  32'hA5);

        if (errors == 0) $display("=== RESULTADO REG_EN: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO REG_EN: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
