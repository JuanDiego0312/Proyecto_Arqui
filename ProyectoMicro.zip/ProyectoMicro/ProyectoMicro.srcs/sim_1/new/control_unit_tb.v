`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : control_unit_tb
 *  Módulo bajo prueba : control_unit (FSM + ALU control + lógica de salto)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar que los tres bloques internos trabajan juntos: que alu_ctrl se
 *    forme con alu_op (de la FSM) y funct3, y que pc_en combine pc_write,
 *    branch y las banderas zero y lt.
 *
 *  ESTÍMULOS
 *    Para cada caso se aplica reset, se fijan opcode, funct3, zero y lt, se
 *    avanza k flancos (k = número de estado dentro de la instrucción) y se
 *    comparan las salidas:
 *      addi (funct3 000): S0, S1, S6 (alu_ctrl ADD), S7        andi (111): S6 -> AND
 *      slli (001): S6 -> SLL
 *      lw: S2, S3, S4        sw y sb: S2, S5        lui: S11        jal: S10, S7
 *      jalr: S9, S10, S7
 *      bne con zero = 0 y 1 ; bge con lt = 0 y 1  (en el estado S8)
 *
 *  RESULTADOS ESPERADOS
 *    S0: pc_en = 1, ADD(0010), ALUSrcA = PC, ALUSrcB = 4.
 *    S6: ADD (addi), AND (andi), SLL (slli).
 *    S8 (bne/bge): alu_ctrl = SUB (0110); pc_en = 1 solo si el salto se cumple
 *    (bne: zero = 0 ; bge: lt = 0) y pc_src = 1.
 *    S10: pc_en = 1, pc_src = 1, OldPC + 4.
 * ============================================================================
 */
module control_unit_tb;

    reg clk, reset;
    reg [6:0] opcode;
    reg [2:0] funct3;
    reg zero, lt;
    wire pc_en, pc_src, ir_write, reg_write, mem_read, mem_write;
    wire [1:0] alu_src_a, alu_src_b, result_src;
    wire [3:0] alu_ctrl;
    integer errors;

    control_unit dut (.clk(clk), .reset(reset), .opcode(opcode), .funct3(funct3),
        .zero(zero), .lt(lt), .pc_en(pc_en), .pc_src(pc_src), .ir_write(ir_write),
        .reg_write(reg_write), .mem_read(mem_read), .mem_write(mem_write),
        .alu_src_a(alu_src_a), .alu_src_b(alu_src_b), .result_src(result_src),
        .alu_ctrl(alu_ctrl));

    always #5 clk = ~clk;

    // Lleva la FSM al estado número k de la instrucción (k = 0 es S0)
    task goto_state;
        input [6:0] op;
        input [2:0] f3;
        input z, l;
        input integer k;
        begin
            opcode = op; funct3 = f3; zero = z; lt = l;
            reset = 1; @(posedge clk); @(negedge clk);
            reset = 0;
            repeat (k) @(posedge clk);
            #1;
        end
    endtask

    // Compara las salidas del estado actual
    task chk;
        input [8*28-1:0] name;
        input pen, pcs, irw, rw, mr, mw;
        input [1:0] asa, asb, rs;
        input [3:0] ac;
        begin
            if (pc_en===pen && pc_src===pcs && ir_write===irw && reg_write===rw &&
                mem_read===mr && mem_write===mw && alu_src_a===asa && alu_src_b===asb &&
                result_src===rs && alu_ctrl===ac)
                $display("[PASS] %0s", name);
            else begin
                $display("[FAIL] %0s: pc_en=%b pc_src=%b irw=%b rw=%b mr=%b mw=%b asa=%b asb=%b rs=%b alu_ctrl=%b",
                         name, pc_en, pc_src, ir_write, reg_write, mem_read, mem_write,
                         alu_src_a, alu_src_b, result_src, alu_ctrl);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE CONTROL_UNIT ===");
        clk = 0; reset = 1; opcode = 0; funct3 = 0; zero = 0; lt = 0;

        // ---- addi / andi / slli (tipo I aritmético) ----
        goto_state(7'b0010011, 3'b000, 0, 0, 0); chk("addi S0 FETCH",   1,0,1,0,0,0, 2'b00,2'b10,2'b00, 4'b0010);
        goto_state(7'b0010011, 3'b000, 0, 0, 1); chk("addi S1 DECODE",  0,0,0,0,0,0, 2'b01,2'b01,2'b00, 4'b0010);
        goto_state(7'b0010011, 3'b000, 0, 0, 2); chk("addi S6 EXEC_I (ADD)", 0,0,0,0,0,0, 2'b10,2'b01,2'b00, 4'b0010);
        goto_state(7'b0010011, 3'b000, 0, 0, 3); chk("addi S7 ALU_WB",  0,0,0,1,0,0, 2'b00,2'b00,2'b00, 4'b0010);
        goto_state(7'b0010011, 3'b111, 0, 0, 2); chk("andi S6 EXEC_I (AND)", 0,0,0,0,0,0, 2'b10,2'b01,2'b00, 4'b0000);
        goto_state(7'b0010011, 3'b001, 0, 0, 2); chk("slli S6 EXEC_I (SLL)", 0,0,0,0,0,0, 2'b10,2'b01,2'b00, 4'b0011);

        // ---- lw (S2 S3 S4) ----
        goto_state(7'b0000011, 3'b010, 0, 0, 2); chk("lw S2 MEM_ADR",   0,0,0,0,0,0, 2'b10,2'b01,2'b00, 4'b0010);
        goto_state(7'b0000011, 3'b010, 0, 0, 3); chk("lw S3 MEM_READ",  0,0,0,0,1,0, 2'b00,2'b00,2'b00, 4'b0010);
        goto_state(7'b0000011, 3'b010, 0, 0, 4); chk("lw S4 MEM_WB",    0,0,0,1,0,0, 2'b00,2'b00,2'b01, 4'b0010);

        // ---- sw y sb (S2 S5) ----
        goto_state(7'b0100011, 3'b010, 0, 0, 3); chk("sw S5 MEM_WRITE", 0,0,0,0,0,1, 2'b00,2'b00,2'b00, 4'b0010);
        goto_state(7'b0100011, 3'b000, 0, 0, 3); chk("sb S5 MEM_WRITE", 0,0,0,0,0,1, 2'b00,2'b00,2'b00, 4'b0010);

        // ---- bne: salta si zero = 0 ----
        goto_state(7'b1100011, 3'b001, 0, 0, 2); chk("bne S8 (zero=0: salta)",    1,1,0,0,0,0, 2'b10,2'b00,2'b00, 4'b0110);
        goto_state(7'b1100011, 3'b001, 1, 0, 2); chk("bne S8 (zero=1: no salta)", 0,1,0,0,0,0, 2'b10,2'b00,2'b00, 4'b0110);

        // ---- bge: salta si lt = 0 ----
        goto_state(7'b1100011, 3'b101, 0, 0, 2); chk("bge S8 (lt=0: salta)",    1,1,0,0,0,0, 2'b10,2'b00,2'b00, 4'b0110);
        goto_state(7'b1100011, 3'b101, 0, 1, 2); chk("bge S8 (lt=1: no salta)", 0,1,0,0,0,0, 2'b10,2'b00,2'b00, 4'b0110);

        // ---- jal (S10 S7) ----
        goto_state(7'b1101111, 3'b000, 0, 0, 2); chk("jal S10 JUMP_LINK", 1,1,0,0,0,0, 2'b01,2'b10,2'b00, 4'b0010);
        goto_state(7'b1101111, 3'b000, 0, 0, 3); chk("jal S7 ALU_WB",     0,0,0,1,0,0, 2'b00,2'b00,2'b00, 4'b0010);

        // ---- jalr (S9 S10 S7) ----
        goto_state(7'b1100111, 3'b000, 0, 0, 2); chk("jalr S9 EXEC_JALR",  0,0,0,0,0,0, 2'b10,2'b01,2'b00, 4'b0010);
        goto_state(7'b1100111, 3'b000, 0, 0, 3); chk("jalr S10 JUMP_LINK", 1,1,0,0,0,0, 2'b01,2'b10,2'b00, 4'b0010);
        goto_state(7'b1100111, 3'b000, 0, 0, 4); chk("jalr S7 ALU_WB",     0,0,0,1,0,0, 2'b00,2'b00,2'b00, 4'b0010);

        // ---- lui (S11) ----
        goto_state(7'b0110111, 3'b000, 0, 0, 2); chk("lui S11 LUI_WB", 0,0,0,1,0,0, 2'b00,2'b00,2'b10, 4'b0010);

        if (errors == 0) $display("=== RESULTADO CONTROL_UNIT: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO CONTROL_UNIT: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
