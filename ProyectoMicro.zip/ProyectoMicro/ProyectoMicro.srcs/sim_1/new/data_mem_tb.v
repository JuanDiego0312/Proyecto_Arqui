`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : data_mem_tb
 *  Módulo bajo prueba : data_mem (ADDR_BITS = 8 -> 256 bytes)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar la lectura combinacional (mem_read), la escritura síncrona de
 *    palabra (sw) y de byte (sb, incluso no alineada), que mem_write = 0 y los
 *    tamaños no soportados no escriban, y que dump_memory genere el archivo
 *    con el formato pedido (criterio de 5 puntos de la rúbrica).
 *
 *  ESTÍMULOS (en orden)
 *    1. sw 0x11223344 en 0xE0 ; lw de 0xE0.
 *    2. sb en 0xE3 con wdata = 0xDEADBE62 (solo cuenta el byte bajo, 0x62).
 *    3. sb en 0xE0, 0xE1 y 0xE2 con 0xAA, 0xBB y 0xCC.
 *    4. mem_read = 0 con addr = 0xE0.
 *    5. mem_write = 0 con funct3 = sw ; y mem_write = 1 con funct3 = 001 (sh).
 *    6. sw 0x0000C7DF en 0xE4 y sw 2 en 0xE8.
 *    7. dump_memory("test_dump.txt") y lectura del archivo generado.
 *
 *  RESULTADOS ESPERADOS
 *    1. lw = 0x11223344.            2. palabra 0xE0 = 0x62223344 (solo cambia 0xE3).
 *    3. palabra 0xE0 = 0x62CCBBAA.  4. rdata = 0.
 *    5. la palabra 0xE0 no cambia.  6. 0xE4 = 0x0000C7DF y 0xE8 = 2.
 *    7. el archivo tiene el encabezado y 64 líneas "0xDIR 0xVALOR";
 *       0xE0 -> 0x62CCBBAA, 0xE4 -> 0x0000C7DF, 0xE8 -> 0x00000002.
 * ============================================================================
 */
module data_mem_tb;

    reg clk, mem_read, mem_write;
    reg [2:0]  funct3;
    reg [31:0] addr, wdata;
    wire [31:0] rdata;
    integer errors;

    // Variables para leer el archivo de volcado
    integer fd, rr, lines;
    reg [8*100-1:0] header;
    reg [31:0] fa, fv;
    reg e0_ok, e4_ok, e8_ok;

    data_mem dut (.clk(clk), .mem_read(mem_read), .mem_write(mem_write),
                  .funct3(funct3), .addr(addr), .wdata(wdata), .rdata(rdata));

    always #5 clk = ~clk;

    task check;
        input [8*40-1:0] name;
        input [31:0] got;
        input [31:0] expected;
        begin
            if (got === expected) $display("[PASS] %0s = 0x%08X", name, got);
            else begin
                $display("[FAIL] %0s = 0x%08X (esperado 0x%08X)", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    // Escribe (sw o sb según funct3) y espera al flanco de reloj
    task write;
        input [2:0]  f3;
        input [31:0] a;
        input [31:0] d;
        begin
            funct3 = f3; addr = a; wdata = d; mem_write = 1;
            @(posedge clk); #1;
            mem_write = 0;
        end
    endtask

    // Lee una palabra (mem_read = 1) y la compara
    task read_check;
        input [8*40-1:0] name;
        input [31:0] a;
        input [31:0] expected;
        begin
            addr = a; mem_read = 1; #2;
            check(name, rdata, expected);
            mem_read = 0;
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE DATA_MEM ===");
        clk = 0; mem_read = 0; mem_write = 0; funct3 = 3'b010; addr = 0; wdata = 0;
        #12;

        // 1. sw y lw
        write(3'b010, 32'hE0, 32'h11223344);
        read_check("sw/lw en 0xE0", 32'hE0, 32'h11223344);

        // 2. sb en dirección no alineada (0xE3): solo cambia ese byte
        write(3'b000, 32'hE3, 32'hDEADBE62);
        read_check("sb 0xE3 -> palabra 0xE0", 32'hE0, 32'h62223344);

        // 3. sb en los otros tres bytes
        write(3'b000, 32'hE0, 32'h000000AA);
        write(3'b000, 32'hE1, 32'h000000BB);
        write(3'b000, 32'hE2, 32'h000000CC);
        read_check("sb en 0xE0,0xE1,0xE2", 32'hE0, 32'h62CCBBAA);

        // 4. Con mem_read = 0 la salida es 0
        addr = 32'hE0; mem_read = 0; #2;
        check("mem_read=0 -> rdata=0", rdata, 32'h0);

        // 5. Sin mem_write o con tamaño no soportado no se escribe
        funct3 = 3'b010; addr = 32'hE0; wdata = 32'hFFFFFFFF; mem_write = 0;
        @(posedge clk); #1;
        read_check("mem_write=0 no escribe", 32'hE0, 32'h62CCBBAA);
        write(3'b001, 32'hE0, 32'hFFFFFFFF);
        read_check("funct3=001 (sh) no escribe", 32'hE0, 32'h62CCBBAA);

        // 6. Valores del programa del profesor
        write(3'b010, 32'hE4, 32'h0000C7DF);
        write(3'b010, 32'hE8, 32'h00000002);
        read_check("0xE4 = r", 32'hE4, 32'h0000C7DF);
        read_check("0xE8 = i", 32'hE8, 32'h00000002);

        // 7. Volcado de memoria y verificación del archivo
        dut.dump_memory("test_dump.txt");
        fd = $fopen("test_dump.txt", "r");
        if (fd == 0) begin
            $display("[FAIL] no se creo test_dump.txt");
            errors = errors + 1;
        end else begin
            rr = $fgets(header, fd);                       // línea de encabezado
            lines = 0; e0_ok = 0; e4_ok = 0; e8_ok = 0;
            while (!$feof(fd)) begin
                rr = $fscanf(fd, "0x%h 0x%h\n", fa, fv);
                if (rr == 2) begin
                    lines = lines + 1;
                    if (fa == 32'hE0 && fv == 32'h62CCBBAA) e0_ok = 1;
                    if (fa == 32'hE4 && fv == 32'h0000C7DF) e4_ok = 1;
                    if (fa == 32'hE8 && fv == 32'h00000002) e8_ok = 1;
                end
            end
            $fclose(fd);
            check("volcado: numero de lineas", lines, 64);
            check("volcado: 0xE0 correcto", e0_ok, 1);
            check("volcado: 0xE4 correcto", e4_ok, 1);
            check("volcado: 0xE8 correcto", e8_ok, 1);
        end

        if (errors == 0) $display("=== RESULTADO DATA_MEM: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO DATA_MEM: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
