`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : reg_file_tb
 *  Módulo bajo prueba : reg_file
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar el reset (x2 = 0x100, resto en 0), la escritura síncrona, la
 *    lectura simultánea de dos registros, que x0 no se pueda escribir y que
 *    con we = 0 no se escriba.
 *
 *  ESTÍMULOS
 *    1. reset = 1 durante 2 flancos; leer x2, x0, x5 y x31.
 *    2. Escribir x5 = 0xCAFEBABE; leer x5 y x2 a la vez (ra1 = 5, ra2 = 2).
 *    3. Intentar escribir x0 = 0xFFFFFFFF; leer x0.
 *    4. we = 0 con wa = 6 y wd = 0x1234; leer x6.
 *    5. Escribir x2 = 0x80 y volver a aplicar reset; leer x2 y x5.
 *
 *  RESULTADOS ESPERADOS
 *    x2 = 0x100, x0 = 0 siempre, x5 = 0xCAFEBABE tras escribir, x6 = 0 sin we,
 *    y tras el segundo reset x2 = 0x100 y x5 = 0.
 * ============================================================================
 */
module reg_file_tb;

    reg clk, reset, we;
    reg [4:0]  ra1, ra2, wa;
    reg [31:0] wd;
    wire [31:0] rd1, rd2;
    integer errors;

    reg_file dut (.clk(clk), .reset(reset), .we(we), .ra1(ra1), .ra2(ra2),
                  .wa(wa), .wd(wd), .rd1(rd1), .rd2(rd2));

    always #5 clk = ~clk;

    task check;
        input [8*40-1:0] name;
        input [31:0] got;
        input [31:0] expected;
        begin
            if (got === expected) $display("[PASS] %0s = 0x%08X", name, got);
            else begin
                $display("[FAIL] %0s = 0x%08X (esperado 0x%08X)", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE REG_FILE ===");
        clk = 0; reset = 1; we = 0; ra1 = 0; ra2 = 0; wa = 0; wd = 0;
        @(posedge clk); @(posedge clk); #1;
        reset = 0;

        // 1. Valores tras el reset
        ra1 = 2;  ra2 = 0;  #1; check("reset: x2 (sp)", rd1, 32'h00000100);
                                check("reset: x0",      rd2, 32'h00000000);
        ra1 = 5;  ra2 = 31; #1; check("reset: x5",      rd1, 32'h00000000);
                                check("reset: x31",     rd2, 32'h00000000);

        // 2. Escritura y lectura simultánea de dos registros
        we = 1; wa = 5; wd = 32'hCAFEBABE; @(posedge clk); #1; we = 0;
        ra1 = 5; ra2 = 2; #1;
        check("x5 escrito (rd1)",    rd1, 32'hCAFEBABE);
        check("x2 intacto (rd2)",    rd2, 32'h00000100);

        // 3. x0 no se puede escribir
        we = 1; wa = 0; wd = 32'hFFFFFFFF; @(posedge clk); #1; we = 0;
        ra1 = 0; #1; check("x0 sigue en 0", rd1, 32'h00000000);

        // 4. Con we = 0 no se escribe
        we = 0; wa = 6; wd = 32'h00001234; @(posedge clk); #1;
        ra1 = 6; #1; check("we=0 no escribe x6", rd1, 32'h00000000);

        // 5. Escribir x2 y aplicar reset otra vez
        we = 1; wa = 2; wd = 32'h00000080; @(posedge clk); #1; we = 0;
        ra1 = 2; #1; check("x2 sobrescrito", rd1, 32'h00000080);
        reset = 1; @(posedge clk); #1; reset = 0;
        ra1 = 2; ra2 = 5; #1;
        check("tras reset: x2", rd1, 32'h00000100);
        check("tras reset: x5", rd2, 32'h00000000);

        if (errors == 0) $display("=== RESULTADO REG_FILE: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO REG_FILE: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
