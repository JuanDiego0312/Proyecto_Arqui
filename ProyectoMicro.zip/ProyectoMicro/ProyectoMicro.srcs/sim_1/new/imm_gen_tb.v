`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : imm_gen_tb
 *  Módulo bajo prueba : imm_gen
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar la extracción y la extensión de signo del inmediato en los
 *    cinco formatos (I, S, B, U, J) con instrucciones reales del programa.
 *
 *  ESTÍMULOS (instrucción -> inmediato esperado)
 *    I: addi sp,sp,-32 (0xFE010113) -> 0xFFFFFFE0 ; slli ,1 (0x00179793) -> 1 ;
 *       andi ,15 (0x00F7F793) -> 0xF ; lw a5,-24(s0) (0xFE842783) -> 0xFFFFFFE8 ;
 *       jalr (0x00008067) -> 0
 *    S: sw s0,28(sp) (0x00812E23) -> 0x1C ; sb a5,-29(s0) (0xFEF401A3) -> 0xFFFFFFE3
 *    B: bne en 0x34 hacia 0x44 (0x00079863) -> 0x10 ;
 *       bge en 0x70 hacia 0x30 (0xFCE7D0E3) -> 0xFFFFFFC0
 *    U: lui a5,0xC (0x0000C7B7) -> 0x0000C000
 *    J: jal en 0x2C hacia 0x68 (0x03C0006F) -> 0x3C ; jal en 0x40 hacia 0x5C (0x01C0006F) -> 0x1C
 *    Vectores extra que mueven TODOS los bits de los formatos B y J:
 *    jal +0x800 (0x001000EF) -> 0x800 ; jal +0xFF000 (0x000FF0EF) -> 0xFF000 ;
 *    jal -2 (0xFFFFF0EF) -> 0xFFFFFFFE ; beq +0x800 (0x000000E3) -> 0x800 ;
 *    bne +0xFFE (0x7E629FE3) -> 0xFFE ; beq -2 (0xFE000FE3) -> 0xFFFFFFFE
 *    Opcode no soportado (0x00000000) -> 0
 *
 *  RESULTADOS ESPERADOS
 *    Todos los inmediatos coinciden (incluidos los negativos con signo extendido).
 * ============================================================================
 */
module imm_gen_tb;

    reg  [31:0] instr;
    wire [31:0] imm;
    integer     errors;

    imm_gen dut (.instr(instr), .imm(imm));

    task check;
        input [8*40-1:0] name;
        input [31:0] i;
        input [31:0] expected;
        begin
            instr = i; #10;
            if (imm === expected) $display("[PASS] %0s imm = 0x%08X", name, imm);
            else begin
                $display("[FAIL] %0s imm = 0x%08X (esperado 0x%08X)", name, imm, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE IMM_GEN ===");
        check("I  addi sp,sp,-32",   32'hFE010113, 32'hFFFFFFE0);
        check("I  slli ,1",          32'h00179793, 32'h00000001);
        check("I  andi ,15",         32'h00F7F793, 32'h0000000F);
        check("I  lw a5,-24(s0)",    32'hFE842783, 32'hFFFFFFE8);
        check("I  jalr",             32'h00008067, 32'h00000000);
        check("S  sw s0,28(sp)",     32'h00812E23, 32'h0000001C);
        check("S  sb a5,-29(s0)",    32'hFEF401A3, 32'hFFFFFFE3);
        check("B  bne (+0x10)",      32'h00079863, 32'h00000010);
        check("B  bge (-0x40)",      32'hFCE7D0E3, 32'hFFFFFFC0);
        check("U  lui a5,0xC",       32'h0000C7B7, 32'h0000C000);
        check("J  jal (+0x3C)",      32'h03C0006F, 32'h0000003C);
        check("J  jal (+0x1C)",      32'h01C0006F, 32'h0000001C);
        check("J  jal +0x800 (bit 11)",   32'h001000EF, 32'h00000800);
        check("J  jal +0xFF000 (19:12)",  32'h000FF0EF, 32'h000FF000);
        check("J  jal -2",                32'hFFFFF0EF, 32'hFFFFFFFE);
        check("B  beq +0x800 (bit 11)",   32'h000000E3, 32'h00000800);
        check("B  bne +0xFFE",            32'h7E629FE3, 32'h00000FFE);
        check("B  beq -2",                32'hFE000FE3, 32'hFFFFFFFE);
        check("opcode no soportado", 32'h00000000, 32'h00000000);
        if (errors == 0) $display("=== RESULTADO IMM_GEN: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO IMM_GEN: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
