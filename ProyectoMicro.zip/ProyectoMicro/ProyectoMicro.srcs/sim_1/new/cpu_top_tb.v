`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : cpu_top_tb
 *  Módulo bajo prueba : cpu_top (procesador completo)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Ejecutar el programa completo del profesor (programa.hex), generar el
 *    volcado de la memoria de datos y comprobar automáticamente el resultado.
 *
 *  REQUISITO
 *    programa.hex debe estar en el directorio de simulación.
 *
 *  ESTÍMULOS
 *    - Reloj de 10 ns y reset inicial de 25 ns.
 *    - El programa termina su primera pasada cuando el ret (jalr en 0x84) lleva
 *      el PC de vuelta a 0. En ese instante se hace el volcado (en la segunda
 *      pasada el byte 0xE3 vale temporalmente 0x63) y se verifica.
 *
 *  RESULTADOS ESPERADOS (primera pasada: 45 instrucciones, unos 185 ciclos)
 *    Memoria: 0xE0 = 0x62000000 (a = 'b'), 0xE4 = 0x0000C7DF (r),
 *             0xE8 = 0x00000002 (i), 0xEC = 0x00000002 (b), 0xFC = 0 (s0 guardado).
 *    Registros: sp (x2) = 0x100 y s0 (x8) = 0.
 *    Archivo memory_dump.txt generado.
 * ============================================================================
 */
module cpu_top_tb;

    reg clk;
    reg reset;

    integer cycle_count;
    integer max_cycles;
    reg     passed_first_pass;
    integer err_count;

    cpu_top dut (.clk(clk), .reset(reset));

    // Reloj de 10 ns
    always #5 clk = ~clk;

    // Reset inicial
    initial begin
        $display("\n========================================================");
        $display("   INICIO DE SIMULACION: MT-7003 RV32I MULTICICLO");
        $display("========================================================\n");
        clk = 0; reset = 1; cycle_count = 0; err_count = 0;
        passed_first_pass = 0;
        max_cycles = 500;           // límite de seguridad
        #25;
        reset = 0;
    end

    // Contador de ciclos con el procesador activo
    always @(posedge clk) begin
        if (!reset) cycle_count = cycle_count + 1;
    end

    // Fin de la primera pasada: el PC vuelve a 0 después de haber avanzado
    always @(posedge clk) begin
        if (!reset && (dut.pc == 32'h0000_0000) && (cycle_count > 50) && !passed_first_pass) begin
            passed_first_pass = 1;
            $display("\n[INFO] Primera pasada concluida en el ciclo: %0d", cycle_count);
            $display("[INFO] Generando volcado de memoria...");

            dut.u_dmem.dump_memory("memory_dump.txt");   // volcado obligatorio
            #10;

            $display("\n========================================================");
            $display("   RESULTADOS ESPERADOS (PASS/FAIL)");
            $display("========================================================");

            check_mem(32'hE0, 32'h62000000, "a = 'b' (byte en 0xE3)");
            check_mem(32'hE4, 32'h0000C7DF, "r = 0xC7DF");
            check_mem(32'hE8, 32'h00000002, "i = 2");
            check_mem(32'hEC, 32'h00000002, "b = (33<<1)&0xF");
            check_mem(32'hFC, 32'h00000000, "s0 guardado");

            check_reg(2, 32'h00000100, "sp (x2)");
            check_reg(8, 32'h00000000, "s0 (x8)");

            $display("--------------------------------------------------------");
            if (err_count == 0) $display(" [EXITO] SIMULACION FINALIZADA SIN ERRORES.");
            else                $display(" [ALERTA] SIMULACION FINALIZADA CON %0d ERRORES.", err_count);
            $display("========================================================\n");
            $finish;
        end
    end

    // Límite de tiempo
    always @(posedge clk) begin
        if (cycle_count >= max_cycles) begin
            $display("\n[ERROR FATAL] Timeout de simulacion (%0d ciclos). PC actual: %h", max_cycles, dut.pc);
            $display("              Verifique que programa.hex este en el directorio de simulacion.");
            $finish;
        end
    end

    // Compara una palabra de la memoria de datos con el valor esperado
    task check_mem;
        input [31:0] addr;
        input [31:0] expected_val;
        input [8*30:1] description;
        reg [31:0] actual_val;
        begin
            actual_val = {dut.u_dmem.mem[addr+3], dut.u_dmem.mem[addr+2],
                          dut.u_dmem.mem[addr+1], dut.u_dmem.mem[addr+0]};
            if (actual_val === expected_val)
                $display(" [PASS] Memoria [0x%02X] = 0x%08X (%0s)", addr, actual_val, description);
            else begin
                $display(" [FAIL] Memoria [0x%02X] = 0x%08X | ESPERADO: 0x%08X (%0s)", addr, actual_val, expected_val, description);
                err_count = err_count + 1;
            end
        end
    endtask

    // Compara un registro del banco con el valor esperado
    task check_reg;
        input [4:0] reg_idx;
        input [31:0] expected_val;
        input [8*20:1] description;
        reg [31:0] actual_val;
        begin
            actual_val = dut.u_rf.regs[reg_idx];
            if (actual_val === expected_val)
                $display(" [PASS] Registro %0s = 0x%08X", description, actual_val);
            else begin
                $display(" [FAIL] Registro %0s = 0x%08X | ESPERADO: 0x%08X", description, actual_val, expected_val);
                err_count = err_count + 1;
            end
        end
    endtask

endmodule
