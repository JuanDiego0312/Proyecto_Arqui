`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : mux2_tb
 *  Módulo bajo prueba : mux2 (WIDTH = 32)
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar la selección entre dos entradas de 32 bits.
 *  ESTÍMULOS
 *    d0 = 0xAAAAAAAA, d1 = 0xBBBBBBBB; sel = 0, luego sel = 1, luego se cambian
 *    d0 y d1 con sel = 1 para confirmar que y sigue a d1.
 *  RESULTADOS ESPERADOS
 *    y = d0 con sel = 0; y = d1 con sel = 1.
 * ============================================================================
 */
module mux2_tb;

    reg sel;
    reg [31:0] d0, d1;
    wire [31:0] y;
    integer errors;

    mux2 #(.WIDTH(32)) dut (.sel(sel), .d0(d0), .d1(d1), .y(y));

    task check;
        input [8*40-1:0] name;
        input [31:0] expected;
        begin
            #10;
            if (y === expected) $display("[PASS] %0s -> 0x%08X", name, y);
            else begin
                $display("[FAIL] %0s -> 0x%08X (esperado 0x%08X)", name, y, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE MUX2 ===");
        d0 = 32'hAAAAAAAA; d1 = 32'hBBBBBBBB;
        sel = 0; check("sel=0 -> d0", 32'hAAAAAAAA);
        sel = 1; check("sel=1 -> d1", 32'hBBBBBBBB);
        d0 = 32'h12345678; d1 = 32'h9ABCDEF0;
        check("sel=1 sigue a d1", 32'h9ABCDEF0);
        sel = 0; check("sel=0 sigue a d0", 32'h12345678);
        if (errors == 0) $display("=== RESULTADO MUX2: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO MUX2: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
