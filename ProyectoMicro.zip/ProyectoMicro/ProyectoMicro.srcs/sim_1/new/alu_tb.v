`timescale 1ns/1ps

/*
 * ============================================================================
 *  Testbench : alu_tb
 *  Módulo bajo prueba : alu
 *
 *  OBJETIVO DE LA PRUEBA
 *    Verificar las 4 operaciones de la ALU (ADD, SUB, AND, SLL), la operación
 *    inválida y las banderas zero y lt (menor que con signo).
 *
 *  ESTÍMULOS (se aplica cada vector y se espera 10 ns antes de comparar)
 *    1-2.  ADD:  5+3 ; 0xFFFFFFFF+1 (desbordamiento a cero)
 *    3-4.  SUB:  7-7 ; 3-5 (resultado negativo)
 *    5-6.  AND:  0x7DF & 0xF ; 0xFF00FF00 & 0x0FF00FF0
 *    7-9.  SLL:  33<<1 ; 1<<31 ; b=33 (solo cuentan los 5 bits bajos -> desplaza 1)
 *    10-12. lt con signo: -1<1 ; 1<-1 ; 5<5
 *    13.   alu_ctrl inválido (1111)
 *
 *  RESULTADOS ESPERADOS
 *    Cada caso imprime [PASS] o [FAIL]; el resumen final indica 0 fallas.
 * ============================================================================
 */
module alu_tb;

    reg  [31:0] a, b;
    reg  [3:0]  alu_ctrl;
    wire [31:0] result;
    wire        zero, lt;
    integer     errors;

    alu dut (.a(a), .b(b), .alu_ctrl(alu_ctrl), .result(result), .zero(zero), .lt(lt));

    // Compara un valor obtenido contra el esperado y cuenta las fallas
    task check;
        input [8*40-1:0] name;
        input [31:0] got;
        input [31:0] expected;
        begin
            if (got === expected) $display("[PASS] %0s = 0x%08X", name, got);
            else begin
                $display("[FAIL] %0s = 0x%08X (esperado 0x%08X)", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        $display("=== INICIO DE PRUEBAS DE ALU ===");

        a = 32'd5;        b = 32'd3;        alu_ctrl = 4'b0010; #10;   // ADD
        check("ADD 5+3", result, 32'd8);
        check("ADD 5+3 zero", zero, 0);

        a = 32'hFFFFFFFF; b = 32'd1;        alu_ctrl = 4'b0010; #10;   // ADD con desbordamiento
        check("ADD 0xFFFFFFFF+1", result, 32'd0);
        check("ADD 0xFFFFFFFF+1 zero", zero, 1);

        a = 32'd7;        b = 32'd7;        alu_ctrl = 4'b0110; #10;   // SUB iguales
        check("SUB 7-7", result, 32'd0);
        check("SUB 7-7 zero", zero, 1);

        a = 32'd3;        b = 32'd5;        alu_ctrl = 4'b0110; #10;   // SUB negativo
        check("SUB 3-5", result, 32'hFFFFFFFE);
        check("SUB 3-5 zero", zero, 0);

        a = 32'h000007DF; b = 32'h0000000F; alu_ctrl = 4'b0000; #10;   // AND (andi b&0xF)
        check("AND 0x7DF & 0xF", result, 32'h0000000F);

        a = 32'hFF00FF00; b = 32'h0FF00FF0; alu_ctrl = 4'b0000; #10;
        check("AND patron", result, 32'h0F000F00);

        a = 32'd33;       b = 32'd1;        alu_ctrl = 4'b0011; #10;   // SLL (slli b<<1)
        check("SLL 33<<1", result, 32'd66);

        a = 32'd1;        b = 32'd31;       alu_ctrl = 4'b0011; #10;
        check("SLL 1<<31", result, 32'h80000000);

        a = 32'd1;        b = 32'd33;       alu_ctrl = 4'b0011; #10;   // solo b[4:0] = 1
        check("SLL usa 5 bits (b=33)", result, 32'd2);

        a = 32'hFFFFFFFF; b = 32'd1;        alu_ctrl = 4'b0110; #10;   // lt con signo
        check("lt -1<1", lt, 1);

        a = 32'd1;        b = 32'hFFFFFFFF; alu_ctrl = 4'b0110; #10;
        check("lt 1<-1", lt, 0);

        a = 32'd5;        b = 32'd5;        alu_ctrl = 4'b0110; #10;
        check("lt 5<5", lt, 0);

        a = 32'd10;       b = 32'd5;        alu_ctrl = 4'b1111; #10;   // operación inválida
        check("operacion invalida", result, 32'd0);

        if (errors == 0) $display("=== RESULTADO ALU: TODAS LAS PRUEBAS PASARON ===");
        else             $display("=== RESULTADO ALU: %0d FALLAS ===", errors);
        $finish;
    end

endmodule
